@extends('layouts.app')

@section('title', 'My Dashboard')

@section('content')
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="{{ route('home') }}">Home</a></span>
                <span class="devider">/</span>
                <span>Dashboard</span>
            </div>
            <div class="blog-heading about-heading d-flex flex-column flex-md-row justify-content-md-between align-items-md-center gap-3">
                <div>
                    <h1 class="heading" data-aos="fade-up">Welcome back, {{ auth()->user()->name }}!</h1>
                    <p class="text-muted mt-2" data-aos="fade-up" data-aos-delay="100">
                        Manage orders, track deliveries, and keep an eye on the styles you’re loving.
                    </p>
                </div>
                <form action="{{ route('logout') }}" method="POST" data-aos="fade-left">
                    @csrf
                    <button type="submit" class="shop-btn view-btn">Logout</button>
                </form>
            </div>
        </div>
    </section>

    <section class="product customer-dashboard">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="dashboard-card" data-aos="fade-up">
                        <div class="dashboard-icon bg-primary-subtle">
                            <i class="bi bi-box2-heart text-primary"></i>
                        </div>
                        <h5>Recent Orders</h5>
                        <p class="text-muted">Track status, download invoices, and request returns.</p>
                        <a href="{{ route('orders.index') }}" class="shop-btn view-btn">View Orders</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="dashboard-card" data-aos="fade-up" data-aos-delay="100">
                        <div class="dashboard-icon bg-success-subtle">
                            <i class="bi bi-bag-check text-success"></i>
                        </div>
                        <h5>Browse Products</h5>
                        <p class="text-muted">Discover curated arrivals and shop by category.</p>
                        <a href="{{ route('products.index') }}" class="shop-btn view-btn">Shop Now</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="dashboard-card" data-aos="fade-up" data-aos-delay="200">
                        <div class="dashboard-icon bg-warning-subtle">
                            <i class="bi bi-heart text-warning"></i>
                        </div>
                        <h5>Your Wishlist</h5>
                        <p class="text-muted">Save favourites and receive restock notifications.</p>
                        <a href="{{ route('wishlist.index') }}" class="shop-btn view-btn">View Wishlist</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="dashboard-card" data-aos="fade-up" data-aos-delay="300">
                        <div class="dashboard-icon bg-info-subtle">
                            <i class="bi bi-truck text-info"></i>
                        </div>
                        <h5>Track Delivery</h5>
                        <p class="text-muted">Stay updated with real-time delivery notifications.</p>
                        <a href="{{ route('orders.index') }}" class="shop-btn view-btn">Track Packages</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="dashboard-card" data-aos="fade-up" data-aos-delay="350">
                        <div class="dashboard-icon bg-danger-subtle">
                            <i class="bi bi-arrow-repeat text-danger"></i>
                        </div>
                        <h5>Returns &amp; Refunds</h5>
                        <p class="text-muted">Submit return requests and review our policy.</p>
                        <a href="{{ route('refund') }}" class="shop-btn view-btn">Learn More</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="dashboard-card" data-aos="fade-up" data-aos-delay="400">
                        <div class="dashboard-icon bg-secondary-subtle">
                            <i class="bi bi-person-gear text-secondary"></i>
                        </div>
                        <h5>Account Preferences</h5>
                        <p class="text-muted">Update shipping addresses, billing details, and passwords.</p>
                        <a href="{{ route('contact') }}" class="shop-btn view-btn">Contact Support</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
