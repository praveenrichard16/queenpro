@extends('layouts.admin')

@section('title', $user->exists ? 'Edit User' : 'Add User')

@section('content')
	<div class="dashboard-main-body">
		<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
			<h6 class="fw-semibold mb-0">{{ $user->exists ? 'Edit User' : 'Add User' }}</h6>
			<ul class="d-flex align-items-center gap-2">
				<li class="fw-medium">
					<a href="{{ route('admin.dashboard') }}" class="d-flex align-items-center gap-1 hover-text-primary">
						<iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
						Dashboard
					</a>
				</li>
				<li>-</li>
				<li class="fw-medium">
					<a href="{{ route('admin.users.index') }}" class="hover-text-primary">Users</a>
				</li>
				<li>-</li>
				<li class="fw-medium text-secondary-light">{{ $user->exists ? 'Edit' : 'Add' }}</li>
			</ul>
		</div>

		@php
			$isSuperAdmin = auth()->user()?->is_super_admin;
		@endphp

		<div class="card border-0">
			<div class="card-body p-24">
				<form method="POST" enctype="multipart/form-data" action="{{ $user->exists ? route('admin.users.update', $user) : route('admin.users.store') }}" class="row g-4">
					@csrf
					@if($user->exists)
						@method('PUT')
					@endif

					<div class="col-lg-6">
						<label class="form-label text-secondary-light">Full Name</label>
						<input type="text" name="name" value="{{ old('name', $user->name) }}" class="form-control bg-neutral-50 radius-12 h-56-px @error('name') is-invalid @enderror" required>
						@error('name') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
					</div>

					<div class="col-lg-6">
						<label class="form-label text-secondary-light">Email</label>
						<input type="email" name="email" value="{{ old('email', $user->email) }}" class="form-control bg-neutral-50 radius-12 h-56-px @error('email') is-invalid @enderror" required>
						@error('email') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
					</div>

					<div class="col-lg-6">
						<label class="form-label text-secondary-light">Phone</label>
						<input type="text" name="phone" value="{{ old('phone', $user->phone) }}" class="form-control bg-neutral-50 radius-12 h-56-px @error('phone') is-invalid @enderror" placeholder="+971 55 000 1234">
						@error('phone') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
					</div>

					@if($isSuperAdmin)
						<div class="col-lg-6">
							<label class="form-label text-secondary-light">Designation <span class="text-secondary-light">(optional)</span></label>
							<input type="text" name="designation" value="{{ old('designation', $user->designation) }}" class="form-control bg-neutral-50 radius-12 h-56-px @error('designation') is-invalid @enderror" placeholder="e.g. Sales Consultant">
							@error('designation') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
						</div>
					@endif

					<div class="col-lg-6">
						<label class="form-label text-secondary-light">Password {{ $user->exists ? '(leave blank to keep current)' : '' }}</label>
						<input type="password" name="password" class="form-control bg-neutral-50 radius-12 h-56-px @error('password') is-invalid @enderror" {{ $user->exists ? '' : 'required' }}>
						@error('password') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
					</div>

					<div class="col-lg-6">
						<label class="form-label text-secondary-light">Confirm Password</label>
						<input type="password" name="password_confirmation" class="form-control bg-neutral-50 radius-12 h-56-px @error('password_confirmation') is-invalid @enderror" {{ $user->exists ? '' : 'required' }}>
						@error('password_confirmation') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
					</div>

					<div class="col-lg-6">
						<label class="form-label text-secondary-light">Avatar</label>
						<input type="file" name="avatar" class="form-control bg-neutral-50 radius-12 h-56-px @error('avatar') is-invalid @enderror">
						@error('avatar') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
						<div class="form-text mt-1">Recommended size: 300 × 300px (JPG/PNG, max 2MB).</div>
					</div>

					@if($user->exists && $user->avatar_path)
					                      <div class="col-lg-6">
						<label class="form-label text-secondary-light d-block">Current Avatar</label>
						<div class="p-16 border radius-12 bg-neutral-50 d-inline-flex">
							<img src="{{ $user->avatar_url }}" class="rounded" style="max-height:140px" alt="{{ $user->name }}">
						</div>
					</div>
					@endif

					@if($isSuperAdmin)
						<div class="col-lg-6">
							@php
								$roleValue = old('role', $user->is_admin ? 'admin' : ($user->is_staff ? 'staff' : 'customer'));
							@endphp
							<label class="form-label text-secondary-light d-block">Role</label>
							<select name="role" class="form-select bg-neutral-50 radius-12 h-56-px @error('role') is-invalid @enderror">
								<option value="customer" @selected($roleValue === 'customer')>Customer</option>
								<option value="staff" @selected($roleValue === 'staff')>Staff</option>
								<option value="admin" @selected($roleValue === 'admin')>Administrator</option>
							</select>
							@error('role') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
							<div class="form-text mt-1">Only super admins can create administrators or internal staff.</div>
						</div>
					@endif

					<div class="col-12 d-flex gap-2 mt-8">
						<button class="btn btn-primary radius-12 px-24">{{ $user->exists ? 'Update User' : 'Create User' }}</button>
						<a href="{{ route('admin.users.index') }}" class="btn btn-outline-secondary radius-12 px-24">Cancel</a>
					</div>
				</form>
			</div>
		</div>
	</div>
@endsection

