@extends('layouts.admin')

@section('title', 'Admin Dashboard')

@section('content')
<div class="dashboard-main-body">
	<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
		<h6 class="fw-semibold mb-0">Dashboard</h6>
		<ul class="d-flex align-items-center gap-2">
			<li class="fw-medium">
				<a href="{{ route('admin.dashboard') }}" class="d-flex align-items-center gap-1 hover-text-primary">
					<iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
					Home
				</a>
			</li>
			<li>-</li>
			<li class="fw-medium text-secondary-light">Analytics</li>
		</ul>
	</div>

	<div class="row row-cols-xxxl-5 row-cols-lg-3 row-cols-sm-2 row-cols-1 gy-4">
		<div class="col">
			<div class="card shadow-none border bg-gradient-start-1 h-100">
				<div class="card-body p-20">
					<div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
						<div>
							<p class="fw-medium text-primary-light mb-1">Total Sales</p>
							<h6 class="mb-0">${{ number_format($totalSales, 2) }}</h6>
						</div>
						<div class="w-50-px h-50-px bg-cyan rounded-circle d-flex justify-content-center align-items-center">
							<iconify-icon icon="solar:wallet-bold" class="text-white text-2xl mb-0"></iconify-icon>
						</div>
					</div>
					<p class="fw-medium text-sm text-primary-light mt-12 mb-0">
						Updated {{ $to->diffForHumans(null, null, true) }}
					</p>
				</div>
			</div>
		</div>
		<div class="col">
			<div class="card shadow-none border bg-gradient-start-2 h-100">
				<div class="card-body p-20">
					<div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
						<div>
							<p class="fw-medium text-primary-light mb-1">Total Orders</p>
							<h6 class="mb-0">{{ number_format($totalOrders) }}</h6>
						</div>
						<div class="w-50-px h-50-px bg-purple rounded-circle d-flex justify-content-center align-items-center">
							<iconify-icon icon="ri:shopping-bag-3-line" class="text-white text-2xl mb-0"></iconify-icon>
						</div>
					</div>
					<p class="fw-medium text-sm text-primary-light mt-12 mb-0">
						{{ $from->format('d M') }} – {{ $to->format('d M') }}
					</p>
				</div>
			</div>
		</div>
		<div class="col">
			<div class="card shadow-none border bg-gradient-start-3 h-100">
				<div class="card-body p-20">
					<div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
						<div>
							<p class="fw-medium text-primary-light mb-1">Customers</p>
							<h6 class="mb-0">{{ number_format($totalCustomers) }}</h6>
						</div>
						<div class="w-50-px h-50-px bg-info rounded-circle d-flex justify-content-center align-items-center">
							<iconify-icon icon="gridicons:multiple-users" class="text-white text-2xl mb-0"></iconify-icon>
						</div>
					</div>
					<p class="fw-medium text-sm text-primary-light mt-12 mb-0">
						Active shoppers across all channels
					</p>
				</div>
			</div>
		</div>
		<div class="col">
			<div class="card shadow-none border bg-gradient-start-4 h-100">
				<div class="card-body p-20">
					<div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
						<div>
							<p class="fw-medium text-primary-light mb-1">Active Products</p>
							<h6 class="mb-0">{{ number_format($totalProducts) }}</h6>
						</div>
						<div class="w-50-px h-50-px bg-success-main rounded-circle d-flex justify-content-center align-items-center">
							<iconify-icon icon="fluent:box-20-filled" class="text-white text-2xl mb-0"></iconify-icon>
						</div>
					</div>
					<p class="fw-medium text-sm text-primary-light mt-12 mb-0">
						Manage inventory from the catalog module.
					</p>
				</div>
			</div>
		</div>
		<div class="col">
			<div class="card shadow-none border bg-gradient-start-5 h-100">
				<div class="card-body p-20">
					<div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
						<div>
							<p class="fw-medium text-primary-light mb-1">Avg. Order Value</p>
							<h6 class="mb-0">
								@php($avgOrder = $totalOrders > 0 ? $totalSales / $totalOrders : 0)
								${{ number_format($avgOrder, 2) }}
							</h6>
						</div>
						<div class="w-50-px h-50-px bg-red rounded-circle d-flex justify-content-center align-items-center">
							<iconify-icon icon="fa6-solid:chart-simple" class="text-white text-2xl mb-0"></iconify-icon>
						</div>
					</div>
					<p class="fw-medium text-sm text-primary-light mt-12 mb-0">
						Average value per completed order
					</p>
				</div>
			</div>
		</div>
	</div>

	<div class="row gy-4 mt-1">
		<div class="col-xxl-6 col-xl-12">
			<div class="card h-100">
				<div class="card-body">
					<div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
						<h6 class="text-lg mb-0">Sales Performance</h6>
						<form class="d-flex align-items-center gap-2 flex-wrap" method="GET" action="{{ route('admin.dashboard') }}">
							<input type="date" name="from" value="{{ $from->toDateString() }}" class="form-control form-control-sm bg-neutral-50 radius-12">
							<input type="date" name="to" value="{{ $to->toDateString() }}" class="form-control form-control-sm bg-neutral-50 radius-12">
							<button class="btn btn-sm btn-primary radius-12 px-16">Apply</button>
						</form>
					</div>
					<div class="d-flex flex-wrap align-items-center gap-2 mt-16">
						<h6 class="mb-0">${{ number_format($salesSeries->sum('total'), 2) }}</h6>
						<span class="text-xs fw-medium text-secondary-light">Sales within the selected period</span>
					</div>
					<div id="salesPerformanceChart" class="pt-28 apexcharts-tooltip-style-1"></div>
				</div>
			</div>
		</div>
		<div class="col-xxl-3 col-xl-6">
			<div class="card h-100 radius-8 border">
				<div class="card-body p-24">
					<h6 class="fw-semibold text-lg mb-16">Order Status</h6>
					<div id="ordersOverviewChart" class="apexcharts-tooltip-z-none"></div>
					<ul class="d-flex flex-column gap-2 mt-24">
						<li class="d-flex align-items-center justify-content-between">
							<span class="text-secondary-light text-sm">Delivered</span>
							<span class="fw-semibold text-primary-light">{{ $ordersSummary['delivered'] }}</span>
						</li>
						<li class="d-flex align-items-center justify-content-between">
							<span class="text-secondary-light text-sm">Pending</span>
							<span class="fw-semibold text-primary-light">{{ $ordersSummary['pending'] }}</span>
						</li>
						<li class="d-flex align-items-center justify-content-between">
							<span class="text-secondary-light text-sm">Cancelled</span>
							<span class="fw-semibold text-primary-light">{{ $ordersSummary['cancelled'] }}</span>
						</li>
						<li class="d-flex align-items-center justify-content-between">
							<span class="text-secondary-light text-sm">Rejected</span>
							<span class="fw-semibold text-primary-light">{{ $ordersSummary['rejected'] }}</span>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="col-xxl-3 col-xl-6">
			<div class="card h-100">
				<div class="card-body p-24">
					<div class="d-flex align-items-center justify-content-between gap-2">
						<h6 class="mb-0 fw-semibold text-lg">Notifications</h6>
						<a href="#" class="text-primary-600 d-flex align-items-center gap-1">
							View All
							<iconify-icon icon="solar:alt-arrow-right-linear" class="icon text-md"></iconify-icon>
						</a>
					</div>
					<div class="mt-24 d-flex flex-column gap-20">
						<div class="d-flex align-items-center gap-12">
							<div class="w-44-px h-44-px radius-12 bg-success-focus d-flex align-items-center justify-content-center">
								<iconify-icon icon="solar:bag-heart-bold-duotone" class="text-success-main text-xl"></iconify-icon>
							</div>
							<div>
								<h6 class="text-md mb-2 fw-medium">New order received</h6>
								<span class="text-secondary-light text-sm">2 mins ago</span>
							</div>
						</div>
						<div class="d-flex align-items-center gap-12">
							<div class="w-44-px h-44-px radius-12 bg-primary-focus d-flex align-items-center justify-content-center">
								<iconify-icon icon="solar:bell-bold-duotone" class="text-primary-main text-xl"></iconify-icon>
							</div>
							<div>
								<h6 class="text-md mb-2 fw-medium">Stock alert</h6>
								<span class="text-secondary-light text-sm">Review low inventory items</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row gy-4 mt-1">
		<div class="col-xxl-9 col-xl-12">
			<div class="card h-100">
				<div class="card-body p-24">
					<div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-16">
						<h6 class="fw-semibold text-lg mb-0">Top Performing Products</h6>
						<a href="{{ route('admin.products.index') }}" class="text-primary-600 d-flex align-items-center gap-1">
							Manage Products
							<iconify-icon icon="solar:alt-arrow-right-linear" class="icon text-md"></iconify-icon>
						</a>
					</div>
					<div class="table-responsive scroll-sm">
						<table class="table bordered-table sm-table mb-0">
							<thead>
								<tr>
									<th>Product</th>
									<th class="text-center">Orders</th>
									<th class="text-end">Revenue</th>
								</tr>
							</thead>
							<tbody>
								@forelse($topProducts as $item)
									<tr>
										<td>
											<div class="d-flex align-items-center gap-3">
												<div class="w-40-px h-40-px radius-12 bg-neutral-200 d-flex align-items-center justify-content-center flex-shrink-0">
													<iconify-icon icon="icon-park-outline:ad-product" class="text-primary-main text-lg"></iconify-icon>
												</div>
												<div>
													<h6 class="text-md mb-0 fw-medium">{{ $item->product->name ?? 'Product #'.$item->product_id }}</h6>
													<span class="text-sm text-secondary-light">SKU: {{ $item->product->sku ?? $item->product_id }}</span>
												</div>
											</div>
										</td>
										<td class="text-center fw-semibold">{{ $item->qty }}</td>
										<td class="text-end fw-semibold">${{ number_format($item->revenue ?? ($item->qty * ($item->product->price ?? 0)), 2) }}</td>
									</tr>
								@empty
									<tr>
										<td colspan="3" class="text-center text-secondary-light py-32">
											No product performance data yet.
										</td>
									</tr>
								@endforelse
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xxl-3 col-xl-12">
			<div class="card h-100">
				<div class="card-body">
					<div class="d-flex align-items-center justify-content-between gap-2">
						<h6 class="mb-0 fw-semibold text-lg">Best Customers</h6>
						<a href="#" class="text-primary-600 d-flex align-items-center gap-1">
							View All
							<iconify-icon icon="solar:alt-arrow-right-linear" class="icon text-md"></iconify-icon>
						</a>
					</div>
					<div class="mt-32 d-flex flex-column gap-24">
						@forelse($topCustomers as $customer)
							<div class="d-flex align-items-center justify-content-between gap-3">
								<div class="d-flex align-items-center gap-12">
									<img src="{{ asset('wowdash/assets/images/avatar/avatar'.(($loop->index % 6) + 1).'.png') }}" alt="avatar" class="w-40-px h-40-px rounded-circle flex-shrink-0">
									<div>
										<h6 class="text-md mb-2 fw-medium">{{ $customer->customer_name ?? $customer->customer_email }}</h6>
										<span class="text-sm text-secondary-light">{{ $customer->customer_email }}</span>
									</div>
								</div>
								<span class="text-primary-light text-md fw-medium">{{ $customer->orders }} orders</span>
							</div>
						@empty
							<p class="text-secondary-light text-sm mb-0">No customer insights yet.</p>
						@endforelse
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@push('scripts')
<script>
	document.addEventListener('DOMContentLoaded', function () {
		const salesLabels = @json($salesSeries->pluck('d')->map(fn($d) => \Carbon\Carbon::parse($d)->format('d M')));
		const salesData = @json($salesSeries->pluck('total'));

		const salesChart = new ApexCharts(document.querySelector('#salesPerformanceChart'), {
			chart: {
				type: 'area',
				height: 320,
				toolbar: { show: false },
				fontFamily: 'Inter, sans-serif'
			},
			dataLabels: { enabled: false },
			stroke: {
				curve: 'smooth',
				width: 2,
			},
			colors: ['#7367F0'],
			fill: {
				type: 'gradient',
				gradient: {
					shadeIntensity: 1,
					opacityFrom: 0.4,
					opacityTo: 0,
					stops: [0, 90, 100]
				}
			},
			series: [{
				name: 'Sales',
				data: salesData
			}],
			xaxis: {
				categories: salesLabels,
				labels: {
					style: {
						colors: '#94A3B8'
					}
				}
			},
			yaxis: {
				labels: {
					formatter: value => '$' + Number(value).toLocaleString(undefined, { minimumFractionDigits: 0 }),
					style: { colors: '#94A3B8' }
				}
			},
			grid: {
				strokeDashArray: 4,
				borderColor: '#E2E8F0'
			},
			tooltip: {
				y: {
					formatter: value => '$' + Number(value).toLocaleString(undefined, { minimumFractionDigits: 2 })
				}
			}
		});
		salesChart.render();

		const ordersChart = new ApexCharts(document.querySelector('#ordersOverviewChart'), {
			chart: {
				type: 'donut',
				height: 260
			},
			series: [
				{{ $ordersSummary['delivered'] }},
				{{ $ordersSummary['pending'] }},
				{{ $ordersSummary['cancelled'] }},
				{{ $ordersSummary['rejected'] }}
			],
			labels: ['Delivered', 'Pending', 'Cancelled', 'Rejected'],
			colors: ['#22C55E', '#F97316', '#F04363', '#A855F7'],
			dataLabels: {
				enabled: false
			},
			legend: {
				show: true,
				position: 'bottom'
			},
			plotOptions: {
				pie: {
					donut: {
						size: '65%',
						labels: {
							show: true,
							total: {
								show: true,
								label: 'Orders',
								formatter: function () {
									return {{ array_sum($ordersSummary) }};
								}
							}
						}
					}
				}
			}
		});
		ordersChart.render();
	});
</script>
@endpush
@endsection
