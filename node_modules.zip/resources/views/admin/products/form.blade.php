@extends('layouts.admin')

@section('title', $product->exists ? 'Edit Product' : 'Add Product')

@section('content')
<div class="dashboard-main-body">
	<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
		<h6 class="fw-semibold mb-0">{{ $product->exists ? 'Edit Product' : 'Add Product' }}</h6>
		<ul class="d-flex align-items-center gap-2">
			<li class="fw-medium">
				<a href="{{ route('admin.dashboard') }}" class="d-flex align-items-center gap-1 hover-text-primary">
					<iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
					Dashboard
				</a>
			</li>
			<li>-</li>
			<li class="fw-medium">
				<a href="{{ route('admin.products.index') }}" class="hover-text-primary">Products</a>
			</li>
			<li>-</li>
			<li class="fw-medium text-secondary-light">{{ $product->exists ? 'Edit' : 'Add' }}</li>
		</ul>
	</div>

	<div class="card border-0">
		<div class="card-body p-24">
			<form method="POST" enctype="multipart/form-data" action="{{ $product->exists ? route('admin.products.update', $product) : route('admin.products.store') }}" class="row g-4">
				@csrf
				@if($product->exists)
					@method('PUT')
				@endif

				<div class="col-lg-6">
					<label class="form-label text-secondary-light">Name</label>
					<input type="text" name="name" class="form-control bg-neutral-50 radius-12 h-56-px @error('name') is-invalid @enderror" value="{{ old('name', $product->name) }}" required>
					@error('name') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
				</div>
				<div class="col-lg-6 d-flex gap-2 align-items-end">
					<div class="flex-grow-1">
						<label class="form-label text-secondary-light">Category</label>
						<select name="category_id" class="form-select bg-neutral-50 radius-12 h-56-px @error('category_id') is-invalid @enderror" required>
							<option value="">Select category</option>
							@foreach($categories as $id => $name)
								<option value="{{ $id }}" @selected(old('category_id', $product->category_id)==$id)>{{ $name }}</option>
							@endforeach
						</select>
						@error('category_id') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
					</div>
					<a href="{{ route('admin.categories.create') }}" class="btn btn-outline-secondary h-56-px radius-12 d-inline-flex align-items-center justify-content-center">
						<iconify-icon icon="solar:add-circle-linear"></iconify-icon>
					</a>
				</div>

				<div class="col-12">
					<label class="form-label text-secondary-light">Description</label>
					<textarea name="description" rows="4" class="form-control bg-neutral-50 radius-12 @error('description') is-invalid @enderror" placeholder="Product details">{{ old('description', $product->description) }}</textarea>
					@error('description') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
				</div>

				<div class="col-md-4">
					<label class="form-label text-secondary-light">Price</label>
					<input type="number" step="0.01" min="0" name="price" class="form-control bg-neutral-50 radius-12 h-56-px @error('price') is-invalid @enderror" value="{{ old('price', $product->price) }}" required>
					@error('price') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
				</div>
				<div class="col-md-4">
					<label class="form-label text-secondary-light">Selling Price</label>
					<input type="number" step="0.01" min="0" name="selling_price" class="form-control bg-neutral-50 radius-12 h-56-px @error('selling_price') is-invalid @enderror" value="{{ old('selling_price', $product->selling_price) }}">
					@error('selling_price') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
				</div>
				<div class="col-md-4">
					<label class="form-label text-secondary-light">Stock Quantity</label>
					<input type="number" min="0" name="stock_quantity" class="form-control bg-neutral-50 radius-12 h-56-px @error('stock_quantity') is-invalid @enderror" value="{{ old('stock_quantity', $product->stock_quantity) }}" required>
					@error('stock_quantity') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
				</div>
				<div class="col-md-4">
					<label class="form-label text-secondary-light">Status</label>
					<select name="is_active" class="form-select bg-neutral-50 radius-12 h-56-px">
						<option value="1" @selected(old('is_active', $product->is_active))>Active</option>
						<option value="0" @selected(!old('is_active', $product->is_active))>Inactive</option>
					</select>
				</div>

				<div class="col-lg-6">
					<label class="form-label text-secondary-light">Primary Image</label>
					<input type="file" name="image" class="form-control bg-neutral-50 radius-12 h-56-px @error('image') is-invalid @enderror">
					@error('image') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
				</div>
				@if($product->image)
					<div class="col-lg-6">
						<label class="form-label text-secondary-light d-block">Current Image</label>
						<div class="p-16 border radius-12 bg-neutral-50 d-inline-flex">
							<img src="{{ $product->image }}" class="rounded" style="max-height:140px" alt="Product image">
						</div>
					</div>
				@endif

				<div class="col-md-12">
					<label class="form-label text-secondary-light">Gallery Images</label>
					<input type="file" name="gallery[]" class="form-control bg-neutral-50 radius-12 @error('gallery.*') is-invalid @enderror" multiple>
					@error('gallery') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
					@error('gallery.*') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
					<div class="form-text mt-1">Recommended: 1200×1200 px (JPG/PNG, max 2MB each).</div>
				</div>

				@if($product->exists && $product->images?->isNotEmpty())
					<div class="col-12">
						<label class="form-label text-secondary-light d-block">Existing Gallery</label>
						<div class="d-flex flex-wrap gap-3">
							@foreach($product->images as $image)
								<div class="position-relative border radius-12 bg-neutral-50 p-12" style="width:140px;">
									<img src="{{ $image->path }}" alt="Gallery image" class="img-fluid rounded mb-2">
									<form action="{{ route('admin.products.images.destroy', [$product, $image]) }}" method="POST" onsubmit="return confirm('Remove this image?')" class="d-grid">
										@csrf
										@method('DELETE')
										<button type="submit" class="btn btn-outline-danger btn-sm radius-12">Remove</button>
									</form>
								</div>
							@endforeach
						</div>
					</div>
				@endif

				<div class="col-lg-6">
					<label class="form-label text-secondary-light">Tags</label>
					<select name="tags[]" class="form-select bg-neutral-50 radius-12 @error('tags') is-invalid @enderror" multiple>
						@foreach($tags as $tag)
							<option value="{{ $tag->id }}" @selected(collect(old('tags', $product->exists ? $product->tags->pluck('id')->all() : []))->contains($tag->id))>{{ $tag->name }}</option>
						@endforeach
					</select>
					@error('tags') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
					@error('tags.*') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
					<div class="form-text mt-1">Hold Ctrl (Cmd on Mac) to select multiple tags.</div>
				</div>
				<div class="col-lg-6 d-flex align-items-end">
					<a href="{{ route('admin.tags.create') }}" class="btn btn-outline-secondary radius-12 h-56-px d-inline-flex align-items-center gap-2">
						<iconify-icon icon="solar:add-circle-linear"></iconify-icon>
						New Tag
					</a>
				</div>

				<div class="col-12">
					<label class="form-label text-secondary-light">Meta Title</label>
					<input type="text" name="meta_title" class="form-control bg-neutral-50 radius-12 @error('meta_title') is-invalid @enderror" value="{{ old('meta_title', $product->meta_title) }}" placeholder="SEO meta title">
					@error('meta_title') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
				</div>
				<div class="col-12">
					<label class="form-label text-secondary-light">Meta Description</label>
					<textarea name="meta_description" rows="3" class="form-control bg-neutral-50 radius-12 @error('meta_description') is-invalid @enderror" placeholder="SEO meta description">{{ old('meta_description', $product->meta_description) }}</textarea>
					@error('meta_description') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
				</div>

				<div class="col-12 d-flex gap-2 mt-8">
					<button class="btn btn-primary radius-12 px-24">{{ $product->exists ? 'Update Product' : 'Create Product' }}</button>
					<a href="{{ route('admin.products.index') }}" class="btn btn-outline-secondary radius-12 px-24">Cancel</a>
				</div>
			</form>
		</div>
	</div>
</div>
@endsection
