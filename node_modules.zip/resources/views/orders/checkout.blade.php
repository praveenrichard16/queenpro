@extends('layouts.app')

@section('title', 'Checkout')

@section('content')
<div class="row">
    <div class="col-md-8">
        <h2>Checkout</h2>
        
        <form action="{{ route('orders.store') }}" method="POST">
            @csrf
            
            <!-- Customer Information -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Customer Information</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="customer_name" class="form-label">Full Name *</label>
                            <input type="text" class="form-control @error('customer_name') is-invalid @enderror" 
                                   id="customer_name" name="customer_name" value="{{ old('customer_name') }}" required>
                            @error('customer_name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="customer_email" class="form-label">Email *</label>
                            <input type="email" class="form-control @error('customer_email') is-invalid @enderror" 
                                   id="customer_email" name="customer_email" value="{{ old('customer_email') }}" required>
                            @error('customer_email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="customer_phone" class="form-label">Phone Number *</label>
                        <input type="tel" class="form-control @error('customer_phone') is-invalid @enderror" 
                               id="customer_phone" name="customer_phone" value="{{ old('customer_phone') }}" required>
                        @error('customer_phone')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Shipping Address -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Shipping Address</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="shipping_street" class="form-label">Street Address *</label>
                        <input type="text" class="form-control @error('shipping_address.street') is-invalid @enderror" 
                               id="shipping_street" name="shipping_address[street]" value="{{ old('shipping_address.street') }}" required>
                        @error('shipping_address.street')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="shipping_city" class="form-label">City *</label>
                            <input type="text" class="form-control @error('shipping_address.city') is-invalid @enderror" 
                                   id="shipping_city" name="shipping_address[city]" value="{{ old('shipping_address.city') }}" required>
                            @error('shipping_address.city')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="shipping_state" class="form-label">State *</label>
                            <input type="text" class="form-control @error('shipping_address.state') is-invalid @enderror" 
                                   id="shipping_state" name="shipping_address[state]" value="{{ old('shipping_address.state') }}" required>
                            @error('shipping_address.state')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="shipping_zip" class="form-label">ZIP Code *</label>
                            <input type="text" class="form-control @error('shipping_address.zip') is-invalid @enderror" 
                                   id="shipping_zip" name="shipping_address[zip]" value="{{ old('shipping_address.zip') }}" required>
                            @error('shipping_address.zip')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="shipping_country" class="form-label">Country *</label>
                        <select class="form-select @error('shipping_address.country') is-invalid @enderror" 
                                id="shipping_country" name="shipping_address[country]" required>
                            <option value="">Select Country</option>
                            <option value="US" {{ old('shipping_address.country') == 'US' ? 'selected' : '' }}>United States</option>
                            <option value="CA" {{ old('shipping_address.country') == 'CA' ? 'selected' : '' }}>Canada</option>
                            <option value="UK" {{ old('shipping_address.country') == 'UK' ? 'selected' : '' }}>United Kingdom</option>
                        </select>
                        @error('shipping_address.country')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Billing Address -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Billing Address</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="billing_street" class="form-label">Street Address *</label>
                        <input type="text" class="form-control @error('billing_address.street') is-invalid @enderror" 
                               id="billing_street" name="billing_address[street]" value="{{ old('billing_address.street') }}" required>
                        @error('billing_address.street')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="billing_city" class="form-label">City *</label>
                            <input type="text" class="form-control @error('billing_address.city') is-invalid @enderror" 
                                   id="billing_city" name="billing_address[city]" value="{{ old('billing_address.city') }}" required>
                            @error('billing_address.city')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="billing_state" class="form-label">State *</label>
                            <input type="text" class="form-control @error('billing_address.state') is-invalid @enderror" 
                                   id="billing_state" name="billing_address[state]" value="{{ old('billing_address.state') }}" required>
                            @error('billing_address.state')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="billing_zip" class="form-label">ZIP Code *</label>
                            <input type="text" class="form-control @error('billing_address.zip') is-invalid @enderror" 
                                   id="billing_zip" name="billing_address[zip]" value="{{ old('billing_address.zip') }}" required>
                            @error('billing_address.zip')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="billing_country" class="form-label">Country *</label>
                        <select class="form-select @error('billing_address.country') is-invalid @enderror" 
                                id="billing_country" name="billing_address[country]" required>
                            <option value="">Select Country</option>
                            <option value="US" {{ old('billing_address.country') == 'US' ? 'selected' : '' }}>United States</option>
                            <option value="CA" {{ old('billing_address.country') == 'CA' ? 'selected' : '' }}>Canada</option>
                            <option value="UK" {{ old('billing_address.country') == 'UK' ? 'selected' : '' }}>United Kingdom</option>
                        </select>
                        @error('billing_address.country')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>

            <!-- Payment Method -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Payment Method</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_method" 
                                   id="cash_on_delivery" value="cash_on_delivery" 
                                   {{ old('payment_method') == 'cash_on_delivery' ? 'checked' : '' }} required>
                            <label class="form-check-label" for="cash_on_delivery">
                                <i class="fas fa-money-bill-wave me-2"></i>Cash on Delivery
                            </label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_method" 
                                   id="credit_card" value="credit_card" 
                                   {{ old('payment_method') == 'credit_card' ? 'checked' : '' }}>
                            <label class="form-check-label" for="credit_card">
                                <i class="fas fa-credit-card me-2"></i>Credit Card
                            </label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="payment_method" 
                                   id="paypal" value="paypal" 
                                   {{ old('payment_method') == 'paypal' ? 'checked' : '' }}>
                            <label class="form-check-label" for="paypal">
                                <i class="fab fa-paypal me-2"></i>PayPal
                            </label>
                        </div>
                    </div>
                    @error('payment_method')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            <!-- Order Notes -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Order Notes (Optional)</h5>
                </div>
                <div class="card-body">
                    <textarea class="form-control" name="notes" rows="3" 
                              placeholder="Any special instructions for your order...">{{ old('notes') }}</textarea>
                </div>
            </div>

            <div class="d-flex justify-content-between">
                <a href="{{ route('cart.index') }}" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i>Back to Cart
                </a>
                <button type="submit" class="btn btn-success btn-lg">
                    <i class="fas fa-credit-card me-2"></i>Place Order
                </button>
            </div>
        </form>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5>Order Summary</h5>
            </div>
            <div class="card-body">
                @foreach($cart as $item)
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <div>
                        <h6 class="mb-0">{{ $item['name'] }}</h6>
                        <small class="text-muted">Qty: {{ $item['quantity'] }}</small>
                    </div>
                    <span>${{ number_format($item['price'] * $item['quantity'], 2) }}</span>
                </div>
                @endforeach
                
                <hr>
                <div class="d-flex justify-content-between mb-2">
                    <span>Subtotal:</span>
                    <span>${{ number_format($total, 2) }}</span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Shipping:</span>
                    <span>Free</span>
                </div>
                <hr>
                <div class="d-flex justify-content-between">
                    <strong>Total:</strong>
                    <strong>${{ number_format($total, 2) }}</strong>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
