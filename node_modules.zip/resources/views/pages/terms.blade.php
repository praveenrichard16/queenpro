@extends('layouts.app')

@section('title', 'Terms & Conditions')

@section('content')
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="{{ route('home') }}">Home</a></span>
                <span class="devider">/</span>
                <span>Terms &amp; Conditions</span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up">Terms &amp; Conditions</h1>
                <p class="text-muted mt-2" data-aos="fade-up" data-aos-delay="100">
                    Please review these terms carefully before using {{ config('app.name') }}. By placing an order you agree to be bound by them.
                </p>
            </div>
        </div>
    </section>

    <section class="product policy">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <article class="policy-wrapper" data-aos="fade-up">
                        <h5>1. Eligibility</h5>
                        <p>
                            You must be at least 18 years old, or purchasing under the supervision of a guardian, to use our platform.
                            Orders placed through unauthorised bots or automated scripts are strictly prohibited.
                        </p>

                        <h5>2. Orders &amp; Acceptance</h5>
                        <p>
                            All orders are subject to stock availability and payment verification. We reserve the right to cancel any order if items
                            become unavailable or if fraudulent activity is suspected.
                        </p>

                        <h5>3. Pricing &amp; Payment</h5>
                        <p>
                            Prices are listed in AED and inclusive of VAT unless stated otherwise. We accept major credit cards and secure digital
                            wallets. Payment data is handled exclusively by certified processors.
                        </p>

                        <h5>4. Shipping Policy</h5>
                        <p>
                            Orders within the UAE typically ship within 1–3 business days. International shipments are subject to customs duties and
                            additional processing times which are the responsibility of the recipient.
                        </p>

                        <h5>5. Returns &amp; Exchanges</h5>
                        <p>
                            Items may be returned within 14 days of delivery in original condition with tags attached. Please review our
                            <a href="{{ route('refund') }}">Refund &amp; Return Policy</a> for complete details.
                        </p>

                        <h5>6. Intellectual Property</h5>
                        <p>
                            All content including imagery, copy, and logos remain the property of {{ config('app.name') }} or its partners. You may not
                            reproduce or redistribute materials without express permission.
                        </p>

                        <h5>7. Governing Law</h5>
                        <p>
                            These terms are governed by the laws of the United Arab Emirates. Any dispute shall be resolved exclusively through the
                            courts of Dubai.
                        </p>

                        <h5>8. Contact</h5>
                        <p>
                            For questions regarding these terms please email <a href="mailto:legal@{{ \Illuminate\Support\Str::slug(config('app.name'), '') }}.com">legal@{{ \Illuminate\Support\Str::slug(config('app.name'), '') }}.com</a>.
                        </p>
                    </article>
                </div>
            </div>
        </div>
    </section>
@endsection

