@extends('layouts.app')

@section('title', 'Contact')

@section('content')
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="{{ route('home') }}">Home</a></span>
                <span class="devider">/</span>
                <span>Contact</span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up">Let’s Talk</h1>
                <p class="text-muted mt-3" data-aos="fade-up" data-aos-delay="100">
                    Our concierge team is on hand Sunday–Thursday, 9am–9pm GST, to help with styling, sizing, and order support.
                </p>
            </div>
        </div>
    </section>

    <section class="contact product footer-padding">
        <div class="container">
            <div class="contact-section">
                <div class="row gy-5">
                    <div class="col-lg-6">
                        <div class="contact-info-section">
                            <div class="contact-information">
                                <h5 class="wrapper-heading">Contact Information</h5>
                                <p class="paragraph">
                                    Drop us a message or visit our showroom lounge in Business Bay. We aim to respond to every enquiry within 24 hours.
                                </p>
                                <div class="contact-wrapper">
                                    <div class="row gy-4">
                                        <div class="col-sm-6">
                                            <div class="wrapper phone">
                                                <div class="wrapper-img">
                                                    <span>
                                                        <img src="{{ asset('shopus/assets/images/homepage-one/payment-img-2.png') }}" alt="Phone">
                                                    </span>
                                                </div>
                                                <div class="wrapper-content">
                                                    <h5 class="wrapper-heading">Phone</h5>
                                                    <p class="paragraph">
                                                        <a href="tel:+971555123456" class="text-reset text-decoration-none">+971 555 123 456</a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="wrapper phone">
                                                <div class="wrapper-img">
                                                    <span>
                                                        <img src="{{ asset('shopus/assets/images/homepage-one/payment-img-3.png') }}" alt="Email">
                                                    </span>
                                                </div>
                                                <div class="wrapper-content">
                                                    <h5 class="wrapper-heading">Email</h5>
                                                    <p class="paragraph">
                                                        <a href="mailto:support@{{ \Illuminate\Support\Str::slug(config('app.name'), '') }}.com" class="text-reset text-decoration-none">
                                                            support@{{ \Illuminate\Support\Str::slug(config('app.name'), '') }}.com
                                                        </a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="wrapper phone">
                                                <div class="wrapper-img">
                                                    <span>
                                                        <img src="{{ asset('shopus/assets/images/homepage-one/payment-img-4.png') }}" alt="Hours">
                                                    </span>
                                                </div>
                                                <div class="wrapper-content">
                                                    <h5 class="wrapper-heading">Support Hours</h5>
                                                    <p class="paragraph">Sunday – Thursday<br/>09:00 – 21:00 GST</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="wrapper phone">
                                                <div class="wrapper-img">
                                                    <span>
                                                        <img src="{{ asset('shopus/assets/images/homepage-one/category-img/watch.webp') }}" alt="WhatsApp">
                                                    </span>
                                                </div>
                                                <div class="wrapper-content">
                                                    <h5 class="wrapper-heading">WhatsApp</h5>
                                                    <p class="paragraph">
                                                        <a href="https://wa.me/971555123456" class="text-reset text-decoration-none">Chat instantly</a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="address">
                                                <div class="contact-address">
                                                    <div class="address-icon">
                                                        <span>
                                                            <img src="{{ asset('shopus/assets/images/homepage-one/payment-img-1.png') }}" alt="Address">
                                                        </span>
                                                    </div>
                                                    <div class="address-content">
                                                        <h5 class="wrapper-heading">Flagship Showroom</h5>
                                                        <p class="paragraph">
                                                            Level 29, Vision Tower, Business Bay, Dubai, United Arab Emirates
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="contact-map">
                                                    <iframe
                                                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3608.34949646277!2d55.27218781501436!3d25.19951483787019!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f43086c0a7a61%3A0x311a2f50b0c0356!2sBusiness%20Bay%2C%20Dubai!5e0!3m2!1sen!2sae!4v1731111111111"
                                                        width="524" height="206" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="question-section login-section">
                            <div class="review-form">
                                <h5 class="comment-title">Send us a message</h5>
                                <div class="account-inner-form">
                                    <div class="review-form-name">
                                        <label for="contact-name" class="form-label">Name*</label>
                                        <input type="text" id="contact-name" class="form-control" placeholder="Full name">
                                    </div>
                                    <div class="review-form-name">
                                        <label for="contact-email" class="form-label">Email*</label>
                                        <input type="email" id="contact-email" class="form-control" placeholder="you@example.com">
                                    </div>
                                    <div class="review-form-name">
                                        <label for="contact-subject" class="form-label">Subject*</label>
                                        <input type="text" id="contact-subject" class="form-control" placeholder="How can we assist?">
                                    </div>
                                </div>
                                <div class="review-textarea">
                                    <label for="contact-message" class="form-label">Message*</label>
                                    <textarea class="form-control" id="contact-message" rows="4" placeholder="Share details and our concierge team will reply shortly."></textarea>
                                </div>
                                <div class="login-btn">
                                    <a href="mailto:support@{{ \Illuminate\Support\Str::slug(config('app.name'), '') }}.com" class="shop-btn">Send Now</a>
                                </div>
                                <p class="small text-muted mt-3 mb-0">
                                    By messaging us you agree to our <a href="{{ route('privacy') }}" class="text-decoration-none">privacy policy</a>.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

