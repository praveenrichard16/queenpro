@extends('layouts.app')

@section('title', 'Wishlist')

@section('content')
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="{{ route('home') }}">Home</a></span>
                <span class="devider">/</span>
                <span>Wishlist</span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up">Your Wishlist</h1>
                <p class="text-muted mt-2" data-aos="fade-up" data-aos-delay="100">
                    Save favourites to revisit later. Sign in to sync across all your devices.
                </p>
            </div>
        </div>
    </section>

    <section class="product wishlist">
        <div class="container">
            <div class="wishlist-section" data-aos="fade-up">
                <div class="empty-state text-center">
                    <img src="{{ asset('shopus/assets/images/homepage-one/empty-wishlist.webp') }}" alt="Empty wishlist" class="mb-4" style="max-width: 320px;">
                    <h4>Your wishlist is feeling lonely</h4>
                    <p class="text-muted">Tap the heart icon on any product to add it here and keep track of looks you love.</p>
                    <div class="d-flex justify-content-center gap-3 mt-4">
                        <a href="{{ route('products.index') }}" class="shop-btn">Shop New Arrivals</a>
                        @auth
                            <a href="{{ route('customer.dashboard') }}" class="shop-btn view-btn">Go to Dashboard</a>
                        @else
                            <a href="{{ route('login') }}" class="shop-btn view-btn">Sign In</a>
                        @endauth
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

