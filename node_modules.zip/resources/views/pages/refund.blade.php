@extends('layouts.app')

@section('title', 'Refund & Return Policy')

@section('content')
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="{{ route('home') }}">Home</a></span>
                <span class="devider">/</span>
                <span>Refund &amp; Return Policy</span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up">Refund &amp; Return Policy</h1>
                <p class="text-muted mt-2" data-aos="fade-up" data-aos-delay="100">
                    Shop confidently—if something isn’t quite right, we’ll help you make it right.
                </p>
            </div>
        </div>
    </section>

    <section class="product policy">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <article class="policy-wrapper" data-aos="fade-up">
                        <h5>1. Return Window</h5>
                        <p>
                            Returns are accepted within 14 days of delivery for UAE orders, and within 21 days for GCC shipments, provided items are
                            unworn, undamaged, and include original packaging.
                        </p>

                        <h5>2. Non-Returnable Items</h5>
                        <p>
                            For hygiene reasons we cannot accept returns on pierced jewellery, intimate apparel, swimwear bottoms, or personalised
                            pieces unless faulty.
                        </p>

                        <h5>3. How to Initiate a Return</h5>
                        <ol>
                            <li>Log in to your account and navigate to <a href="{{ route('customer.dashboard') }}">My Dashboard</a>.</li>
                            <li>Select the order and choose <strong>Request Return</strong>.</li>
                            <li>Our concierge team will schedule a pickup or provide drop-off instructions.</li>
                        </ol>

                        <h5>4. Refunds</h5>
                        <p>
                            Approved returns are refunded to the original payment method within 7 business days of inspection. Store credit is issued
                            instantly once the return is approved.
                        </p>

                        <h5>5. Exchanges</h5>
                        <p>
                            Complimentary size exchanges are available on eligible items within the UAE. International exchanges require a new order
                            to be placed once the original item is refunded.
                        </p>

                        <h5>6. Damaged or Incorrect Items</h5>
                        <p>
                            If you receive a faulty item, please contact us within 48 hours at <a href="mailto:care@{{ \Illuminate\Support\Str::slug(config('app.name'), '') }}.com">care@{{ \Illuminate\Support\Str::slug(config('app.name'), '') }}.com</a>
                            with photos so we can arrange a swift replacement.
                        </p>
                    </article>
                </div>
            </div>
        </div>
    </section>
@endsection

