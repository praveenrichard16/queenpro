@extends('layouts.app')

@section('title', 'Products')

@section('content')
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="{{ route('home') }}">Home</a></span>
                <span class="devider">/</span>
                <span>Shop</span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up">All Products</h1>
                <p class="text-muted mt-2" data-aos="fade-up" data-aos-delay="100">
                    Browse our curated catalogue and filter by category, price, and style to find your next favourite piece.
                </p>
            </div>
        </div>
    </section>

    <section class="product product-listing">
        <div class="container">
            <div class="row gy-5">
                <div class="col-lg-3">
                    <aside class="product-sidebar" data-aos="fade-right">
                        <h5 class="sidebar-title">Filter &amp; Sort</h5>
                        <form method="GET" action="{{ route('products.index') }}" class="sidebar-form">
                            <div class="sidebar-field">
                                <label for="search" class="form-label">Search</label>
                                <input type="text" id="search" name="search" class="form-control" placeholder="Search products..."
                                       value="{{ request('search') }}">
                            </div>

                            <div class="sidebar-field">
                                <label for="category" class="form-label">Category</label>
                                <select id="category" name="category" class="form-select">
                                    <option value="">All Categories</option>
                                    @foreach($categories as $category)
                                        <option value="{{ $category->id }}" {{ request('category') == $category->id ? 'selected' : '' }}>
                                            {{ $category->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="sidebar-field">
                                <label class="form-label">Price Range (AED)</label>
                                <div class="price-range d-flex align-items-center gap-3">
                                    <input type="number" class="form-control" name="min_price" placeholder="Min"
                                           value="{{ request('min_price') }}" min="0" step="0.01">
                                    <span class="text-muted">—</span>
                                    <input type="number" class="form-control" name="max_price" placeholder="Max"
                                           value="{{ request('max_price') }}" min="0" step="0.01">
                                </div>
                            </div>

                            <div class="sidebar-field">
                                <label for="sort" class="form-label">Sort By</label>
                                <select id="sort" name="sort" class="form-select">
                                    <option value="name" {{ request('sort') == 'name' ? 'selected' : '' }}>Name</option>
                                    <option value="price" {{ request('sort') == 'price' ? 'selected' : '' }}>Price</option>
                                </select>
                            </div>

                            <div class="sidebar-field">
                                <label for="order" class="form-label">Order</label>
                                <select id="order" name="order" class="form-select">
                                    <option value="asc" {{ request('order') == 'asc' ? 'selected' : '' }}>Ascending</option>
                                    <option value="desc" {{ request('order') == 'desc' ? 'selected' : '' }}>Descending</option>
                                </select>
                            </div>

                            <div class="d-grid gap-3 mt-4">
                                <button type="submit" class="shop-btn">Apply Filters</button>
                                <a href="{{ route('products.index') }}" class="shop-btn view-btn text-center">Clear Filters</a>
                            </div>
                        </form>
                    </aside>
                </div>

                <div class="col-lg-9">
                    <div class="product-topbar d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4" data-aos="fade-up">
                        <div>
                            <h5 class="mb-1">Showing {{ $products->firstItem() ?? 0 }}–{{ $products->lastItem() ?? 0 }}</h5>
                            <span class="text-muted small">{{ $products->total() }} products found</span>
                        </div>
                        <a href="{{ route('cart.index') }}" class="shop-btn checkout-btn mt-3 mt-md-0">
                            View Cart
                        </a>
                    </div>

                    @if($products->count())
                        <div class="row g-4">
                            @foreach($products as $product)
                                <div class="col-xl-4 col-md-6">
                                    <div class="product-wrapper h-100" data-aos="fade-up" data-aos-delay="{{ $loop->index * 40 }}">
                                        <div class="product-img">
                                            <a href="{{ route('products.show', $product->id) }}">
                                                <img src="{{ $product->image ?: asset('shopus/assets/images/homepage-one/product-img/product-img-2.webp') }}" alt="{{ $product->name }}">
                                            </a>
                                            <div class="product-cart">
                                                <a href="{{ route('wishlist.index') }}" class="wishlist">
                                                    <svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M10.1345 17.8492C-6.02484 9.14915 4.63493 -1.05028 10.1345 4.13302C15.634 -1.05028 26.2938 9.14915 10.1345 17.8492Z" stroke="black" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg>
                                                </a>
                                                <form action="{{ route('cart.add') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="product_id" value="{{ $product->id }}">
                                                    <input type="hidden" name="quantity" value="1">
                                                    <button type="submit" class="cart" {{ $product->stock_quantity <= 0 ? 'disabled' : '' }}>
                                                        <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M7.21219 19.0517C8.02771 19.0517 8.68884 18.3906 8.68884 17.575C8.68884 16.7595 8.02771 16.0984 7.21219 16.0984C6.39666 16.0984 5.73555 16.7595 5.73555 17.575C5.73555 18.3906 6.39666 19.0517 7.21219 19.0517Z" stroke="black" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                                            <path d="M16.402 19.0518C17.2175 19.0518 17.8786 18.3906 17.8786 17.5751C17.8786 16.7596 17.2175 16.0984 16.402 16.0984C15.5865 16.0984 14.9253 16.7596 14.9253 17.5751C14.9253 18.3906 15.5865 19.0518 16.402 19.0518Z" stroke="black" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                                            <path d="M1.59277 1.88586H3.06942L4.8276 12.9607C4.91983 13.5454 5.24229 14.0703 5.72691 14.4375C6.21153 14.8047 6.8186 14.9874 7.43506 14.951L15.884 14.4518C16.4654 14.4168 17.0117 14.1617 17.4071 13.741C17.8026 13.3204 18.0186 12.7672 18.0117 12.1943L17.9063 4.42169C17.8974 3.74725 17.6528 3.10332 17.2247 2.61214C16.7967 2.12096 16.2173 1.81836 15.6015 1.76086L3.55051 0.62207" stroke="black" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        <div class="product-info">
                                            <div class="product-description">
                                                <a href="{{ route('products.show', $product->id) }}" class="product-details">
                                                    {{ $product->name }}
                                                </a>
                                                @if($product->category)
                                                    <span class="product-category">{{ $product->category->name }}</span>
                                                @endif
                                                <div class="price">
                                                    <span class="new-price">{{ $product->formatted_price }}</span>
                                                    <span class="stock">
                                                        {{ $product->stock_quantity > 0 ? $product->stock_quantity . ' in stock' : 'Sold out' }}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <div class="d-flex justify-content-center mt-4">
                            {{ $products->appends(request()->query())->links() }}
                        </div>
                    @else
                        <div class="empty-state text-center" data-aos="fade-up">
                            <img src="{{ asset('shopus/assets/images/homepage-one/empty-wishlist.webp') }}" alt="No products" class="mb-4" style="max-width: 280px;">
                            <h4>No products matched your filters</h4>
                            <p class="text-muted">Try adjusting the filters or explore our highlighted collections.</p>
                            <a href="{{ route('products.index') }}" class="shop-btn mt-3">Reset Filters</a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </section>
@endsection
