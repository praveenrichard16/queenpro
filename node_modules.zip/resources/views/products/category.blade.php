@extends('layouts.app')

@section('title', $category->name)

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
	<h2 class="mb-0">{{ $category->name }}</h2>
	<a href="{{ route('products.index') }}" class="btn btn-outline-secondary">All Products</a>
</div>

@if($products->count() > 0)
	<div class="row">
		@foreach($products as $product)
			<div class="col-lg-3 col-md-4 col-sm-6 mb-4">
				<div class="card h-100 shadow-sm">
					@if($product->image)
						<img src="{{ $product->image }}" class="card-img-top" alt="{{ $product->name }}" style="height: 200px; object-fit: cover;">
					@else
						<img src="https://via.placeholder.com/300x200/6c757d/ffffff?text=No+Image" class="card-img-top" alt="{{ $product->name }}" style="height: 200px; object-fit: cover;">
					@endif
					<div class="card-body d-flex flex-column">
						<h6 class="card-title">{{ $product->name }}</h6>
						<p class="card-text text-muted small">${{ number_format($product->price, 2) }}</p>
						<div class="mt-auto d-grid gap-2">
							<a href="{{ route('products.show', $product->id) }}" class="btn btn-outline-primary btn-sm">View</a>
							<form action="{{ route('cart.add') }}" method="POST" class="d-inline">
								@csrf
								<input type="hidden" name="product_id" value="{{ $product->id }}">
								<input type="hidden" name="quantity" value="1">
								<button type="submit" class="btn btn-primary btn-sm" {{ $product->stock_quantity <= 0 ? 'disabled' : '' }}>
									Add to Cart
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		@endforeach
	</div>
	<div class="d-flex justify-content-center">
		{{ $products->links() }}
	</div>
@else
	<div class="text-center py-5">
		<i class="fas fa-search fa-3x text-muted mb-3"></i>
		<h4>No products found in this category</h4>
		<a href="{{ route('products.index') }}" class="btn btn-primary mt-2">Browse All Products</a>
	</div>
@endif
@endsection
