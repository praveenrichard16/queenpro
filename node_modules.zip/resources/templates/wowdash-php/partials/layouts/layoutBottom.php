<?php include './partials/footer.php' ?>
</main>

<?php include './partials/scripts.php' ?>
</body>

</html>