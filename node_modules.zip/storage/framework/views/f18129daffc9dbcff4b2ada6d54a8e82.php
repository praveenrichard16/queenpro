

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
	<h2>Admin Dashboard</h2>
	<form action="<?php echo e(route('logout')); ?>" method="POST">
		<?php echo csrf_field(); ?>
		<button class="btn btn-outline-danger btn-sm">Logout</button>
	</form>
</div>

<div class="row g-3">
	<div class="col-md-4">
		<div class="card h-100">
			<div class="card-body">
				<h5 class="card-title">Products</h5>
				<p class="card-text">Manage product catalog.</p>
				<a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary btn-sm">View Products</a>
			</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="card h-100">
			<div class="card-body">
				<h5 class="card-title">Orders</h5>
				<p class="card-text">View recent orders.</p>
				<a href="<?php echo e(route('orders.index')); ?>" class="btn btn-primary btn-sm">View Orders</a>
			</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="card h-100">
			<div class="card-body">
				<h5 class="card-title">Customers</h5>
				<p class="card-text">Coming soon.</p>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/dashboards/admin.blade.php ENDPATH**/ ?>