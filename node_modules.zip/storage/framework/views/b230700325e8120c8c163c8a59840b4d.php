

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('body_class', 'home-page'); ?>

<?php $__env->startSection('content'); ?>
    <!--------------- hero-section --------------->
    <section id="hero" class="hero">
        <div class="swiper hero-swiper">
            <div class="swiper-wrapper hero-wrapper">
                <div class="swiper-slide hero-slider-one">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="wrapper-section" data-aos="fade-up">
                                    <div class="wrapper-info">
                                        <h5 class="wrapper-subtitle">
                                            UP TO <span class="wrapper-inner-title">70%</span> OFF
                                        </h5>
                                        <h1 class="wrapper-details">
                                            Fashion Collection Summer Sale
                                        </h1>
                                        <a href="<?php echo e(route('products.index')); ?>" class="shop-btn">Shop Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide hero-slider-two">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="wrapper-section" data-aos="fade-up">
                                    <div class="wrapper-info">
                                        <h5 class="wrapper-subtitle">NEW DROP</h5>
                                        <h1 class="wrapper-details">
                                            Curated Looks <br> For Every Moment
                                        </h1>
                                        <a href="<?php echo e(route('products.index')); ?>" class="shop-btn">Explore Collection</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide hero-slider-three">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="wrapper-section" data-aos="fade-up">
                                    <div class="wrapper-info">
                                        <h5 class="wrapper-subtitle">MEMBERS EXCLUSIVE</h5>
                                        <h1 class="wrapper-details">
                                            Earn Rewards With Every Purchase
                                        </h1>
                                        <a href="<?php echo e(route('products.index')); ?>" class="shop-btn">Join &amp; Save</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </section>
    <!--------------- hero-section-end --------------->

    <!--------------- style-section --------------->
    <section class="product fashion-style">
        <div class="container">
            <div class="style-section">
            <div class="row gy-4 gx-5 gy-lg-0">
                <div class="col-lg-6">
                    <div class="product-wrapper wrapper-one" data-aos="fade-right">
                        <div class="wrapper-info">
                            <span class="wrapper-subtitle">NEW STYLE</span>
                            <h4 class="wrapper-details">
                                Get 65% Offer
                                <span class="wrapper-inner-title">&amp; Elevate</span> your wardrobe.
                            </h4>
                            <a href="<?php echo e(route('products.index')); ?>" class="shop-btn">
                                Shop Now
                                <span>
                                    <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect x="1.45312" y="0.914062" width="9.25346" height="2.05632" transform="rotate(45 1.45312 0.914062)"/>
                                        <rect x="8" y="7.45703" width="9.25346" height="2.05632" transform="rotate(135 8 7.45703)"/>
                                    </svg>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="product-wrapper wrapper-two" data-aos="fade-left">
                        <div class="wrapper-info">
                            <span class="wrapper-subtitle">MEGA OFFER</span>
                            <h4 class="wrapper-details">
                                Luxury Brands
                                <span class="wrapper-inner-title">delivered across</span> the UAE.
                            </h4>
                            <a href="<?php echo e(route('products.index')); ?>" class="shop-btn">
                                Shop Now
                                <span>
                                    <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect x="1.45312" y="0.914062" width="9.25346" height="2.05632" transform="rotate(45 1.45312 0.914062)"/>
                                        <rect x="8" y="7.45703" width="9.25346" height="2.05632" transform="rotate(135 8 7.45703)"/>
                                    </svg>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </section>
    <!--------------- style-section-end --------------->

    <!--------------- category-section--------------->
    <?php if($categories->isNotEmpty()): ?>
        <?php
            $categoryImages = [
                asset('shopus/assets/images/homepage-one/category-img/dresses.webp'),
                asset('shopus/assets/images/homepage-one/category-img/bags.webp'),
                asset('shopus/assets/images/homepage-one/category-img/sweaters.webp'),
                asset('shopus/assets/images/homepage-one/category-img/shoes.webp'),
                asset('shopus/assets/images/homepage-one/category-img/gift.webp'),
                asset('shopus/assets/images/homepage-one/category-img/sneakers.webp'),
                asset('shopus/assets/images/homepage-one/category-img/watch.webp'),
                asset('shopus/assets/images/homepage-one/category-img/cap.webp'),
            ];
        ?>
        <section class="product-category">
            <div class="container">
                <div class="section-title">
                    <h5>Our Categories</h5>
                    <a href="<?php echo e(route('products.index')); ?>" class="view">View All</a>
                </div>
                <div class="category-section">
                    <?php $__currentLoopData = $categories->take(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-wrapper" data-aos="fade-right" data-aos-duration="<?php echo e(100 + ($index % 6) * 100); ?>">
                            <div class="wrapper-img">
                                <img src="<?php echo e($categoryImages[$index % count($categoryImages)]); ?>" alt="<?php echo e($category->name); ?>">
                            </div>
                            <div class="wrapper-info">
                                <a href="<?php echo e(route('products.category', $category->slug)); ?>" class="wrapper-details"><?php echo e($category->name); ?></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <!--------------- category-section-end--------------->

    <!--------------- best seller section --------------->
    <section class="product best-seller">
        <div class="container">
            <div class="best-selling-section">
                <div class="section-title">
                    <h5>Best Sellers</h5>
                    <a href="<?php echo e(route('products.index')); ?>" class="view">View All</a>
                </div>
                <div class="best-selling-items row g-5">
                    <?php $__empty_1 = true; $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $primaryImage = $product->image;
                            if (!$primaryImage && $product->images->isNotEmpty()) {
                                $primaryImage = asset('storage/' . $product->images->first()->path);
                            }
                            $primaryImage = $primaryImage ?: asset('shopus/assets/images/homepage-one/product-img/product-img-1.webp');

                            $hasSalePrice = isset($product->selling_price) && $product->selling_price !== null && $product->selling_price !== '' && $product->selling_price < $product->price;
                            $salePrice = $hasSalePrice ? '$' . number_format($product->selling_price, 2) : null;
                        ?>
                        <div class="col-lg-3 col-md-6">
                            <div class="product-wrapper" data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 50); ?>">
                                <div class="product-img">
                                    <img src="<?php echo e($primaryImage); ?>" alt="<?php echo e($product->name); ?>">
                                    <div class="product-cart-items">
                                        <a href="<?php echo e(route('products.show', $product->id)); ?>" class="cart cart-item">
                                            <span>
                                                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="40" height="40" rx="20" fill="white"/>
                                                    <path d="M12 14.4482V16.5664H12.5466H13.0933V15.3957V14.2204L15.6214 16.7486L18.1496 19.2767L18.5459 18.8759L18.9468 18.4796L16.4186 15.9514L13.8904 13.4232H15.0657H16.2364V12.8766V12.33H14.1182H12V14.4482Z" fill="#181818"/>
                                                    <path d="M12 14.4482V16.5664H12.5466H13.0933V15.3957V14.2204L15.6214 16.7486L18.1496 19.2767L18.5459 18.8759L18.9468 18.4796L16.4186 15.9514L13.8904 13.4232H15.0657H16.2364V12.8766V12.33H14.1182H12V14.4482Z" fill="black" fill-opacity="0.2"/>
                                                    <path d="M23.4345 12.8766V13.4232H24.6052H25.7805L23.2523 15.9514L20.7241 18.4796L21.125 18.8759L21.5213 19.2767L24.0495 16.7486L26.5776 14.2204V15.3957V16.5664H27.1243H27.6709V14.4482V12.33H25.5527H23.4345V12.8766Z" fill="#181818"/>
                                                    <path d="M23.4345 12.8766V13.4232H24.6052H25.7805L23.2523 15.9514L20.7241 18.4796L21.125 18.8759L21.5213 19.2767L24.0495 16.7486L26.5776 14.2204V15.3957V16.5664H27.1243H27.6709V14.4482V12.33H25.5527H23.4345V12.8766Z" fill="black" fill-opacity="0.2"/>
                                                    <path d="M15.6078 23.5905L13.0933 26.1096V24.9343V23.7636H12.5466H12V25.8818V28H14.1182H16.2364V27.4534V26.9067H15.0657H13.8904L16.4186 24.3786L18.9468 21.8504L18.5596 21.4632C18.35 21.2491 18.1633 21.076 18.1496 21.076C18.1359 21.076 16.9926 22.2103 15.6078 23.5905Z" fill="#181818"/>
                                                    <path d="M15.6078 23.5905L13.0933 26.1096V24.9343V23.7636H12.5466H12V25.8818V28H14.1182H16.2364V27.4534V26.9067H15.0657H13.8904L16.4186 24.3786L18.9468 21.8504L18.5596 21.4632C18.35 21.2491 18.1633 21.076 18.1496 21.076C18.1359 21.076 16.9926 22.2103 15.6078 23.5905Z" fill="black" fill-opacity="0.2"/>
                                                    <path d="M21.1113 21.4632L20.7241 21.8504L23.2523 24.3786L25.7805 26.9067H24.6052H23.4345V27.4534V28H25.5527H27.6709V25.8818V23.7636H27.1243H26.5776V24.9343V26.1096L24.0586 23.5905C22.6783 22.2103 21.535 21.076 21.5213 21.076C21.5076 21.076 21.3209 21.2491 21.1113 21.4632Z" fill="#181818"/>
                                                    <path d="M21.1113 21.4632L20.7241 21.8504L23.2523 24.3786L25.7805 26.9067H24.6052H23.4345V27.4534V28H25.5527H27.6709V25.8818V23.7636H27.1243H26.5776V24.9343V26.1096L24.0586 23.5905C22.6783 22.2103 21.535 21.076 21.5213 21.076C21.5076 21.076 21.3209 21.2491 21.1113 21.4632Z" fill="black" fill-opacity="0.2"/>
                                                </svg>
                                            </span>
                                        </a>
                                        <a href="<?php echo e(route('wishlist.index')); ?>" class="favourite cart-item">
                                            <span>
                                                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="40" height="40" rx="20" fill="#AE1C9A"/>
                                                    <path d="M14.6928 12.3935C13.5057 12.54 12.512 13.0197 11.671 13.8546C10.9155 14.6016 10.4615 15.3926 10.201 16.4216C9.73957 18.2049 10.0745 19.9626 11.1835 21.6141C11.8943 22.6723 12.8135 23.6427 14.4993 25.1221C15.571 26.0632 18.8422 28.8096 19.0022 28.9011C19.1511 28.989 19.2069 29 19.5232 29C19.8395 29 19.8953 28.989 20.0442 28.9011C20.2042 28.8096 23.4828 26.0595 24.5471 25.1221C26.2404 23.6354 27.1521 22.6687 27.8629 21.6141C28.9719 19.9626 29.3068 18.2049 28.8454 16.4216C28.5849 15.3926 28.1309 14.6016 27.3754 13.8546C26.6237 13.1113 25.8199 12.6828 24.7667 12.4631C24.2383 12.3533 23.2632 12.3423 22.8018 12.4448C21.5142 12.7194 20.528 13.3529 19.6274 14.4808L19.5232 14.609L19.4227 14.4808C18.5333 13.3749 17.562 12.7414 16.3228 12.4631C15.9544 12.3789 15.1059 12.3423 14.6928 12.3935ZM15.9357 13.5104C16.9926 13.6935 17.9044 14.294 18.6263 15.2864C18.7491 15.4585 18.9017 15.6636 18.9613 15.7478C19.2367 16.1286 19.8098 16.1286 20.0851 15.7478C20.1447 15.6636 20.2973 15.4585 20.4201 15.2864C21.4062 13.9315 22.7795 13.2944 24.2755 13.4958C25.9352 13.7191 27.2303 14.8616 27.7252 16.5424C28.116 17.8717 27.9448 19.2668 27.234 20.5228C26.6386 21.5738 25.645 22.676 23.9145 24.203C23.0772 24.939 19.5567 27.9198 19.5232 27.9198C19.486 27.9198 15.9804 24.95 15.1319 24.203C12.4711 21.8557 11.4217 20.391 11.1686 18.6736C11.0049 17.5641 11.2393 16.3703 11.8087 15.4292C12.6646 14.0121 14.3318 13.2358 15.9357 13.5104Z" fill="#000"/>
                                                </svg>
                                            </span>
                                        </a>
                                        <a href="<?php echo e(route('compare.index')); ?>" class="compaire cart-item">
                                            <span>
                                                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="40" height="40" rx="20" fill="white"/>
                                                    <path d="M18.8948 10.6751C18.8948 11.0444 18.8829 11.3502 18.871 11.3502C18.8591 11.3502 18.6645 11.3859 18.4461 11.4336C14.674 12.1959 11.8588 15.1779 11.3346 18.966C11.2115 19.8316 11.2632 21.1499 11.4498 22.0314C11.9223 24.2867 13.3875 26.4031 15.3252 27.642L15.5515 27.7849L16.1114 27.364C16.4171 27.1337 16.6712 26.9352 16.6712 26.9193C16.6712 26.9074 16.572 26.8439 16.4529 26.7803C15.8453 26.4627 15.0552 25.8274 14.5191 25.2278C13.5026 24.0882 12.8514 22.6984 12.641 21.2372C12.5655 20.6972 12.5655 19.6251 12.641 19.1129C12.8038 18.0289 13.185 17.0044 13.7568 16.1071C14.4715 14.9913 15.5594 14.0145 16.7507 13.4149C17.3542 13.1132 18.192 12.8273 18.7678 12.724L18.8948 12.7002V13.2561C18.8948 13.5618 18.9028 13.812 18.9147 13.812C18.9544 13.812 21.4361 11.9339 21.4361 11.9061C21.4361 11.8783 18.9544 10.0001 18.9147 10.0001C18.9028 10.0001 18.8948 10.3019 18.8948 10.6751Z" fill="#181818"/>
                                                    <path d="M18.8948 10.6751C18.8948 11.0444 18.8829 11.3502 18.871 11.3502C18.8591 11.3502 18.6645 11.3859 18.4461 11.4336C14.674 12.1959 11.8588 15.1779 11.3346 18.966C11.2115 19.8316 11.2632 21.1499 11.4498 22.0314C11.9223 24.2867 13.3875 26.4031 15.3252 27.642L15.5515 27.7849L16.1114 27.364C16.4171 27.1337 16.6712 26.9352 16.6712 26.9193C16.6712 26.9074 16.572 26.8439 16.4529 26.7803C15.8453 26.4627 15.0552 25.8274 14.5191 25.2278C13.5026 24.0882 12.8514 22.6984 12.641 21.2372C12.5655 20.6972 12.5655 19.6251 12.641 19.1129C12.8038 18.0289 13.185 17.0044 13.7568 16.1071C14.4715 14.9913 15.5594 14.0145 16.7507 13.4149C17.3542 13.1132 18.192 12.8273 18.7678 12.724L18.8948 12.7002V13.2561C18.8948 13.5618 18.9028 13.812 18.9147 13.812C18.9544 13.812 21.4361 11.9339 21.4361 11.9061C21.4361 11.8783 18.9544 10.0001 18.9147 10.0001C18.9028 10.0001 18.8948 10.3019 18.8948 10.6751Z" fill="black" fill-opacity="0.2"/>
                                                    <path d="M24.219 12.9662C23.9133 13.1965 23.6671 13.399 23.679 13.4149C23.6909 13.4347 23.81 13.5102 23.949 13.5856C25.1124 14.2448 26.1964 15.3566 26.8675 16.5914C27.2725 17.334 27.614 18.414 27.7092 19.2558C27.7887 19.9189 27.741 21.0585 27.614 21.662C27.066 24.2589 25.2593 26.3514 22.7657 27.2806C22.452 27.3957 21.6023 27.63 21.4911 27.63C21.4474 27.63 21.4355 27.5307 21.4355 27.0741C21.4355 26.7684 21.4276 26.5182 21.4157 26.5182C21.376 26.5182 18.8943 28.3963 18.8943 28.4241C18.8943 28.4519 21.376 30.3301 21.4157 30.3301C21.4276 30.3301 21.4355 30.0283 21.4355 29.6551V28.984L21.5864 28.9602C21.9557 28.9006 23 28.6187 23.3415 28.4837C26.4386 27.2726 28.559 24.5884 28.9997 21.3166C29.1149 20.4748 29.0633 19.1565 28.8806 18.2988C28.4081 16.0435 26.9429 13.9271 25.0052 12.6882L24.7789 12.5453L24.219 12.9662Z" fill="#181818"/>
                                                    <path d="M24.219 12.9662C23.9133 13.1965 23.6671 13.399 23.679 13.4149C23.6909 13.4347 23.81 13.5102 23.949 13.5856C25.1124 14.2448 26.1964 15.3566 26.8675 16.5914C27.2725 17.334 27.614 18.414 27.7092 19.2558C27.7887 19.9189 27.741 21.0585 27.614 21.662C27.066 24.2589 25.2593 26.3514 22.7657 27.2806C22.452 27.3957 21.6023 27.63 21.4911 27.63C21.4474 27.63 21.4355 27.5307 21.4355 27.0741C21.4355 26.7684 21.4276 26.5182 21.4157 26.5182C21.376 26.5182 18.8943 28.3963 18.8943 28.4241C18.8943 28.4519 21.376 30.3301 21.4157 30.3301C21.4276 30.3301 21.4355 30.0283 21.4355 29.6551V28.984L21.5864 28.9602C21.9557 28.9006 23 28.6187 23.3415 28.4837C26.4386 27.2726 28.559 24.5884 28.9997 21.3166C29.1149 20.4748 29.0633 19.1565 28.8806 18.2988C28.4081 16.0435 26.9429 13.9271 25.0052 12.6882L24.7789 12.5453L24.219 12.9662Z" fill="black" fill-opacity="0.2"/>
                                                </svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                                <div class="product-info text-center">
                                    <div class="ratings">
                                        <span>
                                            <svg width="75" height="15" viewBox="0 0 75 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7.5 0L9.18386 5.18237H14.6329L10.2245 8.38525L11.9084 13.5676L7.5 10.3647L3.09161 13.5676L4.77547 8.38525L0.367076 5.18237H5.81614L7.5 0Z" fill="#FFA800"/>
                                                <path d="M22.5 0L24.1839 5.18237H29.6329L25.2245 8.38525L26.9084 13.5676L22.5 10.3647L18.0916 13.5676L19.7755 8.38525L15.3671 5.18237H20.8161L22.5 0Z" fill="#FFA800"/>
                                                <path d="M37.5 0L39.1839 5.18237H44.6329L40.2245 8.38525L41.9084 13.5676L37.5 10.3647L33.0916 13.5676L34.7755 8.38525L30.3671 5.18237H35.8161L37.5 0Z" fill="#FFA800"/>
                                                <path d="M52.5 0L54.1839 5.18237H59.6329L55.2245 8.38525L56.9084 13.5676L52.5 10.3647L48.0916 13.5676L49.7755 8.38525L45.3671 5.18237H50.8161L52.5 0Z" fill="#FFA800"/>
                                                <path d="M67.5 0L69.1839 5.18237H74.6329L70.2245 8.38525L71.9084 13.5676L67.5 10.3647L63.0916 13.5676L64.7755 8.38525L60.3671 5.18237H65.8161L67.5 0Z" fill="#FFA800"/>
                                            </svg>
                                        </span>
                                    </div>
                                    <div class="product-description">
                                        <a href="<?php echo e(route('products.show', $product->id)); ?>" class="product-details"><?php echo e($product->name); ?></a>
                                        <div class="price">
                                            <?php if($hasSalePrice): ?>
                                                <span class="price-cut"><?php echo e($product->formatted_price); ?></span>
                                                <span class="new-price"><?php echo e($salePrice); ?></span>
                                            <?php else: ?>
                                                <span class="new-price"><?php echo e($product->formatted_price); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-cart-btn text-center">
                                    <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="quantity" value="1">
                                        <button type="submit" class="product-btn" <?php echo e($product->stock_quantity <= 0 ? 'disabled' : ''); ?>>
                                            <?php echo e($product->stock_quantity > 0 ? 'Add To Cart' : 'Out of Stock'); ?>

                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12">
                            <div class="product-wrapper text-center w-100">
                                <div class="empty-state text-center">
                                    <img src="<?php echo e(asset('shopus/assets/images/homepage-one/empty-wishlist.webp')); ?>" alt="No products" class="mb-4" style="max-width: 320px;">
                                    <h4>No featured products yet</h4>
                                    <p class="text-muted">Check back soon for new arrivals.</p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <!--------------- best seller section end --------------->

    <!--------------- flash-sale-section --------------->
    <section class="product flash-sale">
        <div class="container">
            <div class="section-title">
                <h5>Flash Sale</h5>
                <a href="<?php echo e(route('products.index')); ?>" class="view">View All</a>
            </div>
            <div class="flash-sale-wrapper" data-aos="fade-up">
                <div class="row gy-4">
                    <div class="col-lg-6">
                        <div class="sale-banner">
                            <img src="<?php echo e(asset('shopus/assets/images/homepage-one/flash-sale.webp')); ?>" alt="Flash sale" class="w-100 rounded-4">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="sale-content">
                            <h3>Limited Time Offers</h3>
                            <p class="text-muted">Exclusive drops refreshed daily. Grab them before they are gone.</p>
                            <ul class="sale-list">
                                <li><i class="bi bi-check2-circle"></i> Handpicked capsule edits.</li>
                                <li><i class="bi bi-check2-circle"></i> Complimentary same-day delivery in Dubai.</li>
                                <li><i class="bi bi-check2-circle"></i> Members earn double loyalty points.</li>
                            </ul>
                            <a href="<?php echo e(route('products.index')); ?>" class="shop-btn mt-3">Shop Flash Sale</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--------------- flash-sale-section-end --------------->

    <!--------------- newsletter-section --------------->
    <section class="product newsletter">
        <div class="container">
            <div class="newsletter-section">
                <div class="row align-items-center gy-4">
                    <div class="col-lg-6">
                        <div class="newsletter-info" data-aos="fade-right">
                            <h4 class="newsletter-title">
                                Stay in the loop with exclusive drops and private sales.
                            </h4>
                            <p class="newsletter-desc">
                                Subscribe to receive the latest arrivals, curated edits, and invite-only events.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <form class="newsletter-form" data-aos="fade-left">
                            <input type="email" placeholder="Enter your email" required>
                            <button type="submit" class="shop-btn">Subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--------------- newsletter-section-end --------------->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .home-page .best-selling-section {
            background: linear-gradient(92deg, #fecaff 1.23%, #c9ddfa 97.37%);
            padding: 3rem;
            border-radius: 1.2rem;
        }

        .home-page .best-selling-section .best-selling-items {
            margin-top: 2.4rem;
        }

        .home-page .best-selling-section .product-wrapper {
            width: 100%;
            height: 44.5rem;
            padding: 0 0 2rem 0;
            border-radius: 1.2rem;
            background-color: #ffffff;
            box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
            font-family: 'Jost', sans-serif;
        }

        .home-page .best-selling-section .product-img {
            position: relative;
            width: 100%;
            height: 28rem;
            border-radius: 1.2rem;
            overflow: hidden;
            background: rgba(174, 28, 154, 0.08);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .home-page .best-selling-section .product-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.4s ease;
        }

        .home-page .best-selling-section .product-wrapper:hover .product-img img {
            transform: scale(1.05);
        }

        .home-page .best-selling-section .product-cart-items {
            position: absolute;
            bottom: 2.4rem;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            align-items: center;
            gap: 1rem;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .home-page .best-selling-section .product-wrapper:hover .product-cart-items {
            opacity: 1;
            visibility: visible;
        }

        .home-page .best-selling-section .product-info {
            padding: 0 2rem;
            margin-top: 1.6rem;
            display: flex;
            flex-direction: column;
            gap: 1.2rem;
        }

        .home-page .best-selling-section .ratings {
            display: flex;
            justify-content: center;
        }

        .home-page .best-selling-section .product-description .product-details {
            font-size: 1.8rem;
            font-weight: 500;
            color: #232532;
            display: block;
            text-decoration: none;
        }

        .home-page .best-selling-section .product-description .product-details:hover {
            color: #AE1C9A;
        }

        .home-page .best-selling-section .price {
            display: inline-flex;
            align-items: center;
            gap: 1rem;
            font-size: 1.6rem;
        }

        .home-page .best-selling-section .price-cut {
            color: #7b7d8c;
            text-decoration: line-through;
        }

        .home-page .best-selling-section .new-price {
            color: #232532;
            font-weight: 600;
        }

        .home-page .best-selling-section .product-cart-btn {
            padding: 0 2rem;
            margin-top: auto;
        }

        .home-page .best-selling-section .product-cart-btn form {
            display: inline-block;
            width: 100%;
        }

        .home-page .best-selling-section .product-cart-btn .product-btn {
            width: 100%;
            border: none;
            padding: 1.2rem 1.6rem 1.2rem 2.5rem;
            border-top-left-radius: 3rem;
            background: rgba(174, 28, 154, 0.188);
            color: #AE1C9A;
            font-size: 1.6rem;
            transition: all 0.4s;
            cursor: pointer;
        }

        .home-page .best-selling-section .product-cart-btn .product-btn:hover {
            background-color: #AE1C9A;
            color: #FFFFFF;
        }

        .home-page .best-selling-section .product-cart-btn .product-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        @media (max-width: 1200px) {
            .home-page .best-selling-section {
                padding: 2.4rem;
            }

            .home-page .best-selling-section .product-wrapper {
                height: 40rem;
            }

            .home-page .best-selling-section .product-img {
                height: 24rem;
            }
        }

        @media (max-width: 767px) {
            .home-page .best-selling-section {
                padding: 2rem;
            }

            .home-page .best-selling-section .product-wrapper {
                height: auto;
            }

            .home-page .best-selling-section .product-img {
                height: 20rem;
            }
        }
    </style>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/home.blade.php ENDPATH**/ ?>