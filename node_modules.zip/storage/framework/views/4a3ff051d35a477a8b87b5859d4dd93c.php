

<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>
	<div class="dashboard-main-body">
		<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
			<div>
				<h6 class="fw-semibold mb-0">Users</h6>
				<p class="text-secondary-light mb-0">Manage customers and administrators for the storefront.</p>
			</div>
			<ul class="d-flex align-items-center gap-2">
				<li class="fw-medium">
					<a href="<?php echo e(route('admin.dashboard')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
						<iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
						Dashboard
					</a>
				</li>
				<li>-</li>
				<li class="fw-medium text-secondary-light">Users</li>
			</ul>
		</div>

		<?php if(session('success')): ?>
			<div class="alert alert-success alert-dismissible fade show" role="alert">
				<?php echo e(session('success')); ?>

				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
			</div>
		<?php endif; ?>
		<?php if(session('error')): ?>
			<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<?php echo e(session('error')); ?>

				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
			</div>
		<?php endif; ?>

		<div class="card border-0 shadow-none bg-base mb-24">
			<div class="card-body p-24">
				<form method="GET" class="row gy-3 gx-3 align-items-end">
					<div class="col-xl-4 col-lg-6">
						<label class="form-label text-secondary-light">Search</label>
						<div class="icon-field">
							<span class="icon top-50 translate-middle-y">
								<iconify-icon icon="mage:search"></iconify-icon>
							</span>
							<input type="text" name="search" value="<?php echo e($search); ?>" class="form-control h-56-px bg-neutral-50 radius-12" placeholder="Search name, email or phone">
						</div>
					</div>
					<div class="col-xl-3 col-lg-6">
						<label class="form-label text-secondary-light">Role</label>
						<select name="role" class="form-select h-56-px bg-neutral-50 radius-12">
							<option value="">All roles</option>
							<option value="admin" <?php if($selectedRole === 'admin'): echo 'selected'; endif; ?>>Admins</option>
							<option value="customer" <?php if($selectedRole === 'customer'): echo 'selected'; endif; ?>>Customers</option>
						</select>
					</div>
					<div class="col-xl-2 col-lg-6 d-flex gap-2">
						<button class="btn btn-primary flex-grow-1 h-56-px radius-12">Apply</button>
						<a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-secondary h-56-px radius-12">
							<iconify-icon icon="mi:refresh"></iconify-icon>
						</a>
					</div>
					<div class="col-xl-3 col-lg-6 text-lg-end">
						<a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-warning radius-12 text-white d-inline-flex align-items-center gap-2 h-56-px">
							<iconify-icon icon="solar:user-plus-linear"></iconify-icon>
							Add User
						</a>
					</div>
				</form>
			</div>
		</div>

		<div class="card basic-data-table border-0">
			<div class="card-body p-0">
				<div class="table-responsive">
					<table class="table bordered-table mb-0 align-middle">
						<thead>
							<tr>
								<th scope="col">User</th>
								<th scope="col">Contact</th>
								<th scope="col">Role</th>
								<th scope="col">Verified</th>
								<th scope="col" class="text-end">Actions</th>
							</tr>
						</thead>
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr>
									<td>
										<div class="d-flex align-items-center gap-3">
											<img src="<?php echo e($user->avatar_url); ?>" alt="<?php echo e($user->name); ?>" class="w-48-px h-48-px rounded-circle object-fit-cover">
											<div>
												<h6 class="text-md fw-semibold mb-4"><?php echo e($user->name); ?></h6>
												<?php if($user->designation): ?>
													<span class="text-sm text-secondary-light"><?php echo e($user->designation); ?></span>
												<?php endif; ?>
											</div>
										</div>
									</td>
									<td>
										<div class="d-flex flex-column gap-1">
											<a href="mailto:<?php echo e($user->email); ?>" class="text-decoration-none text-secondary-light"><?php echo e($user->email); ?></a>
											<?php if($user->phone): ?>
												<a href="tel:<?php echo e($user->phone); ?>" class="text-decoration-none text-secondary-light"><?php echo e($user->phone); ?></a>
											<?php endif; ?>
										</div>
									</td>
									<td>
										<span class="px-20 py-6 rounded-pill fw-semibold text-sm <?php echo e($user->is_admin ? 'bg-primary-focus text-primary-main' : 'bg-neutral-200 text-neutral-600'); ?>">
											<?php echo e($user->is_admin ? 'Administrator' : 'Customer'); ?>

										</span>
									</td>
									<td>
										<?php if($user->email_verified_at): ?>
											<span class="badge bg-success-subtle text-success">Verified</span>
										<?php else: ?>
											<span class="badge bg-neutral-200 text-neutral-600">Pending</span>
										<?php endif; ?>
									</td>
									<td class="text-end">
										<div class="d-inline-flex gap-2">
											<a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="w-36-px h-36-px bg-primary-focus text-primary-main rounded-circle d-inline-flex align-items-center justify-content-center" title="Edit">
												<iconify-icon icon="lucide:edit"></iconify-icon>
											</a>
											<form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST" onsubmit="return confirm('Delete this user?')">
												<?php echo csrf_field(); ?>
												<?php echo method_field('DELETE'); ?>
												<button type="submit" class="w-36-px h-36-px bg-danger-focus text-danger-main rounded-circle border-0 d-inline-flex align-items-center justify-content-center" title="Delete">
													<iconify-icon icon="mingcute:delete-2-line"></iconify-icon>
												</button>
											</form>
										</div>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<tr>
									<td colspan="5" class="text-center py-80">
										<img src="<?php echo e(asset('wowdash/assets/images/notification/empty-message-icon1.png')); ?>" alt="No users" class="mb-16" style="max-width:120px;">
										<h6 class="fw-semibold mb-8">No users found</h6>
										<p class="text-secondary-light mb-0">Try adjusting your filters or add a new user.</p>
									</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>

				<?php if($users->hasPages()): ?>
					<div class="card-footer border-0 bg-transparent py-16 px-24">
						<?php echo e($users->links()); ?>

					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/admin/users/index.blade.php ENDPATH**/ ?>