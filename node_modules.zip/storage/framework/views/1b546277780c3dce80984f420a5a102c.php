

<?php use Illuminate\Support\Str; ?>

<?php $__env->startSection('title', 'Support Tickets'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-body">
	<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
		<div>
			<h6 class="fw-semibold mb-4">Support Tickets</h6>
			<p class="text-secondary-light mb-0">Monitor incoming support requests, track SLA status, and jump into conversations.</p>
		</div>
		<ul class="d-flex align-items-center gap-2">
			<li class="fw-medium">
				<a href="<?php echo e(route('admin.dashboard')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
					<iconify-icon icon="solar:home-smile-angle-outline" class="icon text-lg"></iconify-icon>
					Dashboard
				</a>
			</li>
			<li>-</li>
			<li class="fw-medium text-secondary-light">Support Tickets</li>
			<li>
				<a href="<?php echo e(route('admin.support.settings.edit')); ?>" class="btn btn-outline-secondary radius-12 px-18 d-flex align-items-center gap-2">
					<iconify-icon icon="solar:settings-line-duotone"></iconify-icon>
					Settings
				</a>
			</li>
		</ul>
	</div>

	<div class="row g-3 mb-24">
		<?php
			$statusColorMap = [
				'open' => 'bg-primary-50 text-primary-600',
				'in_progress' => 'bg-warning-50 text-warning',
				'awaiting_customer' => 'bg-info-50 text-info-main',
				'resolved' => 'bg-success-50 text-success',
				'closed' => 'bg-neutral-100 text-secondary-light',
			];
			$totalTickets = $statusCounts->sum();
		?>

		<div class="col-xl-2 col-sm-4 col-6">
			<div class="card border-0 h-100">
				<div class="card-body p-20">
					<span class="text-sm text-secondary-light d-block mb-2">Total</span>
					<h5 class="mb-0"><?php echo e($totalTickets); ?></h5>
				</div>
			</div>
		</div>

		<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php
				$count = $statusCounts->get($status->value, 0);
				$badgeClass = $statusColorMap[$status->value] ?? 'bg-neutral-100 text-secondary-light';
			?>
			<div class="col-xl-2 col-sm-4 col-6">
				<div class="card border-0 h-100 <?php echo e($count ? 'shadow-sm' : ''); ?>">
					<div class="card-body p-20">
						<span class="text-sm text-secondary-light d-flex align-items-center gap-2 mb-8">
							<span class="badge <?php echo e($badgeClass); ?> px-10 py-6 radius-8 text-xs fw-semibold"><?php echo e(strtoupper(str_replace('_', ' ', $status->value))); ?></span>
						</span>
						<h5 class="mb-0"><?php echo e($count); ?></h5>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	<div class="card border-0">
		<div class="card-body p-24">
			<form method="GET" action="<?php echo e(route('admin.support.tickets.index')); ?>" class="row g-3 align-items-end mb-20">
				<div class="col-xl-3 col-md-6">
					<label class="form-label text-secondary-light">Search</label>
					<input type="text" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" class="form-control bg-neutral-50 radius-12" placeholder="Ticket number or subject">
				</div>
				<div class="col-xl-2 col-md-4">
					<label class="form-label text-secondary-light">Status</label>
					<select name="status" class="form-select bg-neutral-50 radius-12">
						<option value="">All statuses</option>
						<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($status->value); ?>" <?php if(($filters['status'] ?? '') === $status->value): echo 'selected'; endif; ?>><?php echo e($status->label()); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="col-xl-2 col-md-4">
					<label class="form-label text-secondary-light">Priority</label>
					<select name="priority" class="form-select bg-neutral-50 radius-12">
						<option value="">All priorities</option>
						<?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($priority->value); ?>" <?php if(($filters['priority'] ?? '') === $priority->value): echo 'selected'; endif; ?>><?php echo e($priority->label()); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="col-xl-3 col-md-6">
					<label class="form-label text-secondary-light">Assignee</label>
					<select name="assignee" class="form-select bg-neutral-50 radius-12">
						<option value="">Any</option>
						<?php $__currentLoopData = $assignees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($assignee->id); ?>" <?php if(($filters['assignee'] ?? '') == $assignee->id): echo 'selected'; endif; ?>><?php echo e($assignee->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="col-md-2 d-flex gap-2">
					<button class="btn btn-primary radius-12 flex-grow-1">Filter</button>
					<?php if(!empty($filters)): ?>
						<a href="<?php echo e(route('admin.support.tickets.index')); ?>" class="btn btn-outline-secondary radius-12">Reset</a>
					<?php endif; ?>
				</div>
			</form>

			<div class="table-responsive">
				<table class="table align-middle mb-0">
					<thead>
						<tr>
							<th class="text-secondary-light text-uppercase text-xs fw-semibold">Ticket</th>
							<th class="text-secondary-light text-uppercase text-xs fw-semibold">Subject</th>
							<th class="text-secondary-light text-uppercase text-xs fw-semibold">Customer</th>
							<th class="text-secondary-light text-uppercase text-xs fw-semibold">Priority</th>
							<th class="text-secondary-light text-uppercase text-xs fw-semibold">Status</th>
							<th class="text-secondary-light text-uppercase text-xs fw-semibold">Assignee</th>
							<th class="text-secondary-light text-uppercase text-xs fw-semibold text-end">Updated</th>
						</tr>
					</thead>
					<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td class="fw-semibold">
								<a href="<?php echo e(route('admin.support.tickets.show', $ticket)); ?>" class="text-decoration-none hover-text-primary"><?php echo e($ticket->ticket_number); ?></a>
								<div class="text-xs text-secondary-light"><?php echo e(optional($ticket->category)->name ?? 'General'); ?></div>
							</td>
							<td>
								<div class="fw-medium text-sm"><?php echo e(Str::limit($ticket->subject, 64)); ?></div>
								<?php if($ticket->meta && !empty($ticket->meta['channel'])): ?>
									<span class="badge bg-neutral-100 text-secondary-light radius-8 text-xs mt-1"><?php echo e(ucfirst($ticket->meta['channel'])); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<?php if($ticket->customer): ?>
									<div class="fw-medium text-sm"><?php echo e($ticket->customer->name); ?></div>
									<div class="text-xs text-secondary-light"><?php echo e($ticket->customer->email); ?></div>
								<?php else: ?>
									<span class="badge bg-neutral-100 text-secondary-light radius-8 text-xs">Guest</span>
								<?php endif; ?>
							</td>
							<td>
								<span class="badge radius-8 text-xs fw-semibold
									<?php if($ticket->priority->value === 'urgent'): ?> bg-danger-50 text-danger
									<?php elseif($ticket->priority->value === 'high'): ?> bg-warning-50 text-warning
									<?php elseif($ticket->priority->value === 'medium'): ?> bg-info-50 text-info-main
									<?php else: ?> bg-neutral-100 text-secondary-light <?php endif; ?>">
									<?php echo e($ticket->priority->label()); ?>

								</span>
							</td>
							<td>
								<span class="badge radius-8 text-xs fw-semibold <?php echo e($statusColorMap[$ticket->status->value] ?? 'bg-neutral-100 text-secondary-light'); ?>">
									<?php echo e($ticket->status->label()); ?>

								</span>
							</td>
							<td>
								<?php if($ticket->assignee): ?>
									<div class="fw-medium text-sm"><?php echo e($ticket->assignee->name); ?></div>
								<?php else: ?>
									<span class="text-secondary-light text-sm">Unassigned</span>
								<?php endif; ?>
							</td>
							<td class="text-end text-sm text-secondary-light">
								<?php echo e($ticket->updated_at?->diffForHumans()); ?>

							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<tr>
							<td colspan="7" class="text-center py-24 text-secondary-light">
								No tickets found for the current filters.
							</td>
						</tr>
					<?php endif; ?>
					</tbody>
				</table>
			</div>

			<div class="mt-24">
				<?php echo e($tickets->links()); ?>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/admin/tickets/index.blade.php ENDPATH**/ ?>