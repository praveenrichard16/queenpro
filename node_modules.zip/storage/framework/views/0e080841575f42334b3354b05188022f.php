

<?php $__env->startSection('title', 'Support Notification Settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-main-body">
	<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-24">
		<div>
			<h6 class="fw-semibold mb-0">Support Notification Settings</h6>
			<p class="text-secondary-light mb-0">Control how ticket notifications are delivered and configure default SLA targets.</p>
		</div>
		<ul class="d-flex align-items-center gap-2">
			<li class="fw-medium">
				<a href="<?php echo e(route('admin.support.tickets.index')); ?>" class="d-flex align-items-center gap-1 hover-text-primary">
					<iconify-icon icon="solar:lifebuoy-outline" class="icon text-lg"></iconify-icon>
					Support Tickets
				</a>
			</li>
			<li>-</li>
			<li class="fw-medium text-secondary-light">Notification Settings</li>
		</ul>
	</div>

	<?php if(session('success')): ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
			<?php echo e(session('success')); ?>

			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>
	<?php endif; ?>

	<?php if($errors->any()): ?>
		<div class="alert alert-danger alert-dismissible fade show" role="alert">
			Please review the highlighted fields below.
			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>
	<?php endif; ?>

	<div class="card border-0">
		<div class="card-body p-24">
			<form action="<?php echo e(route('admin.support.settings.update')); ?>" method="POST" class="row g-4">
				<?php echo csrf_field(); ?>
				<div class="col-12">
					<div class="form-check form-switch">
						<input class="form-check-input" type="checkbox" id="support_email_enabled" name="support_email_enabled" value="1" <?php echo e(old('support_email_enabled', $settings['support_email_enabled']) ? 'checked' : ''); ?>>
						<label class="form-check-label text-secondary-light" for="support_email_enabled">
							Enable email notifications for new tickets and updates
						</label>
					</div>
				</div>

				<div class="col-12">
					<label class="form-label text-secondary-light">Team notification recipients</label>
					<textarea name="support_notify_addresses" rows="3" class="form-control bg-neutral-50 radius-12 <?php $__errorArgs = ['support_notify_addresses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="support@example.com, manager@example.com"><?php echo e(old('support_notify_addresses', $settings['support_notify_addresses'])); ?></textarea>
					<div class="form-text">Separate email addresses with commas. These contacts receive alerts for new tickets and assignment changes.</div>
					<?php $__errorArgs = ['support_notify_addresses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="col-md-6">
					<div class="form-check form-switch">
						<input class="form-check-input" type="checkbox" id="support_email_customer_updates" name="support_email_customer_updates" value="1" <?php echo e(old('support_email_customer_updates', $settings['support_email_customer_updates']) ? 'checked' : ''); ?>>
						<label class="form-check-label text-secondary-light" for="support_email_customer_updates">
							Send email updates to customers when staff replies
						</label>
					</div>
				</div>

				<div class="col-md-6">
					<label class="form-label text-secondary-light">Default SLA policy</label>
					<select name="support_default_sla_id" class="form-select bg-neutral-50 radius-12 <?php $__errorArgs = ['support_default_sla_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
						<option value="">No default SLA</option>
						<?php $__currentLoopData = $availableSlas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($sla->id); ?>" <?php if(old('support_default_sla_id', $settings['support_default_sla_id']) == $sla->id): echo 'selected'; endif; ?>><?php echo e($sla->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<div class="form-text">Applied automatically when customers submit tickets.</div>
					<?php $__errorArgs = ['support_default_sla_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>

				<div class="col-12 d-flex gap-3">
					<button class="btn btn-primary radius-12 px-24">Save Settings</button>
					<a href="<?php echo e(route('admin.support.tickets.index')); ?>" class="btn btn-outline-secondary radius-12 px-24">Cancel</a>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/admin/tickets/settings.blade.php ENDPATH**/ ?>