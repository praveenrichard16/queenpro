

<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="<?php echo e(route('home')); ?>">Home</a></span>
                <span class="devider">/</span>
                <?php if($product->category): ?>
                    <span><a href="<?php echo e(route('products.category', $product->category->slug)); ?>"><?php echo e($product->category->name); ?></a></span>
                    <span class="devider">/</span>
                <?php endif; ?>
                <span><?php echo e($product->name); ?></span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up"><?php echo e($product->name); ?></h1>
                <p class="text-muted mt-2" data-aos="fade-up" data-aos-delay="100">
                    Crafted with premium materials and delivered with unbeatable service.
                </p>
            </div>
        </div>
    </section>

    <section class="product product-info">
        <div class="container">
            <div class="row gy-5">
                <div class="col-lg-6">
                    <div class="product-gallery" data-aos="fade-right">
                        <div class="product-main">
                            <img src="<?php echo e($product->image ?: asset('shopus/assets/images/homepage-one/product-img/product-img-5.webp')); ?>" alt="<?php echo e($product->name); ?>">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="product-summary" data-aos="fade-left">
                        <div class="product-price mb-3">
                            <span class="new-price"><?php echo e($product->formatted_price); ?></span>
                            <span class="stock-status <?php echo e($product->stock_quantity > 0 ? 'in-stock' : 'out-stock'); ?>">
                                <?php echo e($product->stock_quantity > 0 ? $product->stock_quantity . ' in stock' : 'Sold out'); ?>

                            </span>
                        </div>
                        <div class="product-description">
                            <p><?php echo e($product->description); ?></p>
                        </div>
                        <?php if($product->stock_quantity > 0): ?>
                            <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="product-cart-actions">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <div class="quantity-selector">
                                    <label for="quantity" class="form-label">Quantity</label>
                                    <input type="number" id="quantity" name="quantity" class="form-control" value="1" min="1" max="<?php echo e($product->stock_quantity); ?>">
                                </div>
                                <div class="d-flex flex-column flex-sm-row gap-3">
                                    <button type="submit" class="shop-btn flex-fill">Add to Cart</button>
                                    <a href="<?php echo e(route('cart.index')); ?>" class="shop-btn view-btn flex-fill">View Cart</a>
                                </div>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-warning d-flex align-items-center gap-2">
                                <i class="bi bi-exclamation-triangle-fill"></i>
                                <div>This product is currently out of stock. Join our mailing list to hear when it returns.</div>
                            </div>
                        <?php endif; ?>

                        <div class="product-services mt-4">
                            <div class="service-item">
                                <i class="bi bi-truck"></i>
                                <div>
                                    <h6>Same-day Dubai delivery</h6>
                                    <span>Order before 4pm GST for same-day dispatch within Dubai.</span>
                                </div>
                            </div>
                            <div class="service-item">
                                <i class="bi bi-arrow-repeat"></i>
                                <div>
                                    <h6>14-day returns</h6>
                                    <span>Free exchanges and easy returns on eligible items.</span>
                                </div>
                            </div>
                            <div class="service-item">
                                <i class="bi bi-shield-lock"></i>
                                <div>
                                    <h6>Secure checkout</h6>
                                    <span>Trusted payment gateways with PCI DSS compliance.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if($relatedProducts->count() > 0): ?>
        <section class="product related-products">
            <div class="container">
                <div class="section-title" data-aos="fade-up">
                    <h5>You might also like</h5>
                    <a href="<?php echo e(route('products.index')); ?>" class="view">View All</a>
                </div>
                <div class="row g-4">
                    <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-lg-4 col-sm-6">
                            <div class="product-wrapper h-100" data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 40); ?>">
                                <div class="product-img">
                                    <a href="<?php echo e(route('products.show', $relatedProduct->id)); ?>">
                                        <img src="<?php echo e($relatedProduct->image ?: asset('shopus/assets/images/homepage-one/product-img/product-img-7.webp')); ?>" alt="<?php echo e($relatedProduct->name); ?>">
                                    </a>
                                    <div class="product-cart">
                                        <a href="<?php echo e(route('wishlist.index')); ?>" class="wishlist">
                                            <svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M10.1345 17.8492C-6.02484 9.14915 4.63493 -1.05028 10.1345 4.13302C15.634 -1.05028 26.2938 9.14915 10.1345 17.8492Z" stroke="black" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </a>
                                        <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="product_id" value="<?php echo e($relatedProduct->id); ?>">
                                            <input type="hidden" name="quantity" value="1">
                                            <button type="submit" class="cart" <?php echo e($relatedProduct->stock_quantity <= 0 ? 'disabled' : ''); ?>>
                                                <svg width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7.21219 19.0517C8.02771 19.0517 8.68884 18.3906 8.68884 17.575C8.68884 16.7595 8.02771 16.0984 7.21219 16.0984C6.39666 16.0984 5.73555 16.7595 5.73555 17.575C5.73555 18.3906 6.39666 19.0517 7.21219 19.0517Z" stroke="black" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M16.402 19.0518C17.2175 19.0518 17.8786 18.3906 17.8786 17.5751C17.8786 16.7596 17.2175 16.0984 16.402 16.0984C15.5865 16.0984 14.9253 16.7596 14.9253 17.5751C14.9253 18.3906 15.5865 19.0518 16.402 19.0518Z" stroke="black" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M1.59277 1.88586H3.06942L4.8276 12.9607C4.91983 13.5454 5.24229 14.0703 5.72691 14.4375C6.21153 14.8047 6.8186 14.9874 7.43506 14.951L15.884 14.4518C16.4654 14.4168 17.0117 14.1617 17.4071 13.741C17.8026 13.3204 18.0186 12.7672 18.0117 12.1943L17.9063 4.42169C17.8974 3.74725 17.6528 3.10332 17.2247 2.61214C16.7967 2.12096 16.2173 1.81836 15.6015 1.76086L3.55051 0.62207" stroke="black" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <div class="product-info">
                                    <div class="product-description">
                                        <a href="<?php echo e(route('products.show', $relatedProduct->id)); ?>" class="product-details">
                                            <?php echo e($relatedProduct->name); ?>

                                        </a>
                                        <div class="price">
                                            <span class="new-price"><?php echo e($relatedProduct->formatted_price); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/products/show.blade.php ENDPATH**/ ?>