<footer class="product footer">
    <div class="container">
        <div class="footer-service-section">
            <div class="row gy-4">
                <div class="col-lg-3 col-sm-6">
                    <div class="service-wrapper free-shipping">
                        <div class="service-img">
                            <img src="<?php echo e(asset('shopus/assets/images/homepage-one/icon.png')); ?>" alt="Free Shipping">
                        </div>
                        <div class="service-content">
                            <h5>Free Shipping</h5>
                            <p>Enjoy free shipping on every order above $99.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="service-wrapper secure-payment">
                        <div class="service-img">
                            <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-1.png')); ?>" alt="Secure Payment">
                        </div>
                        <div class="service-content">
                            <h5>Secure Payment</h5>
                            <p>Protected checkout with trusted payment partners.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="service-wrapper support-team">
                        <div class="service-img">
                            <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-2.png')); ?>" alt="Support">
                        </div>
                        <div class="service-content">
                            <h5>Support 24/7</h5>
                            <p>Expert support team ready to assist you anytime.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="service-wrapper return-policy">
                        <div class="service-img">
                            <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-3.png')); ?>" alt="Return">
                        </div>
                        <div class="service-content">
                            <h5>Easy Return</h5>
                            <p>Hassle-free returns within 30 days of purchase.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-main">
            <div class="row gy-4">
                <div class="col-lg-3 col-sm-6">
                    <div class="footer-order">
                        <div class="logo mb-3">
                            <img src="<?php echo e(asset('shopus/assets/images/logos/footer-logo.webp')); ?>" alt="<?php echo e(config('app.name')); ?>">
                        </div>
                        <p class="text-muted small mb-4">
                            <?php echo e(config('app.name')); ?> brings the best of fashion, accessories, and lifestyle essentials right to your doorstep.
                        </p>
                        <div class="footer-link order-link">
                            <ul>
                                <li><a href="<?php echo e(route('orders.index')); ?>">Track Order</a></li>
                                <li><a href="<?php echo e(route('cart.index')); ?>">Delivery &amp; Returns</a></li>
                                <li><a href="<?php echo e(route('refund')); ?>">Refund Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="about-us">
                        <h4 class="footer-heading footer-title">About</h4>
                        <div class="footer-link about-link">
                            <ul>
                                <li><a href="<?php echo e(route('about')); ?>">Our Story</a></li>
                                <li><a href="<?php echo e(route('contact')); ?>">Work With Us</a></li>
                                <li><a href="<?php echo e(route('privacy')); ?>">Corporate News</a></li>
                                <li><a href="<?php echo e(route('contact')); ?>">Investors Relations</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="links">
                        <h4 class="footer-heading footer-title">Useful Links</h4>
                        <div class="footer-link useful-link">
                            <ul>
                                <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                                <li><a href="<?php echo e(route('terms')); ?>">Terms &amp; Conditions</a></li>
                                <li><a href="<?php echo e(route('wishlist.index')); ?>">Wishlist</a></li>
                                <li><a href="<?php echo e(route('compare.index')); ?>">Compare Products</a></li>
                                <li><a href="<?php echo e(route('refund')); ?>">Refund Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="contact-info">
                        <h4 class="footer-heading footer-title">Contact Info</h4>
                        <div class="footer-link contact-link">
                            <div class="address d-flex">
                                <span class="me-3">
                                    <svg width="44" height="45" viewBox="0 0 44 45" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="21.9995" cy="22.9961" r="21.5" stroke="#424242"></circle>
                                    </svg>
                                </span>
                                <div class="details">
                                    <h6 class="footer-heading mb-1">Address</h6>
                                    <p class="mb-0 small">4517 Emirates Towers, Business Bay, Dubai, UAE</p>
                                </div>
                            </div>
                            <div class="phone address d-flex mt-3">
                                <span class="me-3">
                                    <svg width="44" height="45" viewBox="0 0 44 45" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="21.9995" cy="22.9961" r="21.5" stroke="#424242"></circle>
                                    </svg>
                                </span>
                                <div class="details">
                                    <h6 class="footer-heading mb-1">Call Us</h6>
                                    <p class="mb-0 small">
                                        <a href="tel:+971555123456" class="text-reset text-decoration-none">+971 555 123 456</a>
                                    </p>
                                </div>
                            </div>
                            <div class="email address d-flex mt-3">
                                <span class="me-3">
                                    <svg width="44" height="45" viewBox="0 0 44 45" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="21.9995" cy="22.9961" r="21.5" stroke="#424242"></circle>
                                    </svg>
                                </span>
                                <div class="details">
                                    <h6 class="footer-heading mb-1">Email</h6>
                                    <p class="mb-0 small">
                                        <a href="mailto:support@example.com" class="text-reset text-decoration-none">support@example.com</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <hr class="my-4">
        <div class="footer-bottom d-flex flex-column flex-lg-row justify-content-between align-items-center gap-3">
            <p class="mb-0 small text-muted">&copy; <?php echo e(now()->year); ?> <?php echo e(config('app.name')); ?>. All rights reserved.</p>
            <div class="payment-methods d-flex gap-3 align-items-center">
                <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-1.png')); ?>" alt="Visa">
                <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-2.png')); ?>" alt="Mastercard">
                <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-3.png')); ?>" alt="Paypal">
                <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-4.png')); ?>" alt="Stripe">
            </div>
        </div>
    </div>
</footer>

<?php /**PATH D:\xampp\htdocs\ecom123\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>