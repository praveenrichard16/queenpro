

<?php $__env->startSection('title', 'Compare Products'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="<?php echo e(route('home')); ?>">Home</a></span>
                <span class="devider">/</span>
                <span>Compare</span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up">Compare Products</h1>
                <p class="text-muted mt-2" data-aos="fade-up" data-aos-delay="100">
                    Add up to four items to compare details side by side and make the smartest choice.
                </p>
            </div>
        </div>
    </section>

    <section class="product compaire">
        <div class="container">
            <div class="compare-table" data-aos="fade-up">
                <div class="empty-state text-center">
                    <img src="<?php echo e(asset('shopus/assets/images/homepage-one/empty-cart.webp')); ?>" alt="Compare" class="mb-4" style="max-width: 320px;">
                    <h4>No products in comparison yet</h4>
                    <p class="text-muted">
                        Browse the catalogue and select “Add to Compare” to analyse materials, sizing, and pricing at a glance.
                    </p>
                    <a href="<?php echo e(route('products.index')); ?>" class="shop-btn mt-3">Start Shopping</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/pages/compare.blade.php ENDPATH**/ ?>