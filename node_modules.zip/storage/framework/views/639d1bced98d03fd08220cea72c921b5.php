<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
		<title><?php echo $__env->yieldContent('title', 'WowDash Admin'); ?></title>
		<?php
			$favicon = !empty($appSettings['site_favicon'])
				? asset('storage/'.$appSettings['site_favicon'])
				: asset('wowdash/assets/images/favicon.png');
			$siteLogoLight = !empty($appSettings['site_logo'])
				? asset('storage/'.$appSettings['site_logo'])
				: asset('wowdash/assets/images/logo.png');
			$siteLogoDark = !empty($appSettings['site_logo_dark'])
				? asset('storage/'.$appSettings['site_logo_dark'])
				: $siteLogoLight;

			// Always display the dark logo throughout the admin dashboard when provided.
			if (!empty($appSettings['site_logo_dark'])) {
				$siteLogoLight = $siteLogoDark;
			}

			$siteLogoIcon = $siteLogoDark;
			$adminUser = auth()->user();
			$adminAvatar = $adminUser?->avatar_url ?? asset('wowdash/assets/images/avatar/avatar-1.png');
		?>
		<link rel="icon" type="image/png" href="<?php echo e($favicon); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/remixicon.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/bootstrap.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/apexcharts.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/dataTables.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/editor-katex.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/editor.atom-one-dark.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/editor.quill.snow.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/flatpickr.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/full-calendar.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/jquery-jvectormap-2.0.5.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/magnific-popup.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/slick.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/prism.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/file-upload.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/lib/audioplayer.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('wowdash/assets/css/style.css')); ?>">
	<style>
			.sidebar-menu > li.active > a,
			.sidebar-menu > li > a:hover {
				background-color: #024550 !important;
				color: #ffffff !important;
			}
			.sidebar-menu > li > a:hover .menu-icon,
			.sidebar-menu > li.active > a .menu-icon {
				color: #ffffff !important;
			}
			.btn-primary,
			.btn-warning,
			.btn-success,
			.btn-danger,
			.btn-info,
			.btn-outline-primary,
			.btn-outline-secondary,
			.btn-outline-success,
			.btn-outline-danger,
			.btn-outline-warning,
			.btn-outline-info,
			.btn.btn-link.text-decoration-none,
			.btn,
			button[type="submit"],
			input[type="submit"] {
				background-color: #024550 !important;
				border-color: #024550 !important;
				color: #ffffff !important;
			}

			.btn:hover,
			.btn:focus,
			.btn:active {
				background-color: #03606a !important;
				border-color: #03606a !important;
				color: #ffffff !important;
			}

			.btn-outline-secondary,
			.btn-outline-secondary:hover,
			.btn-outline-secondary:focus {
				background-color: transparent !important;
				color: #024550 !important;
				border-color: #024550 !important;
			}

			.btn-outline-secondary:hover,
			.btn-outline-secondary:focus {
				background-color: rgba(2, 69, 80, 0.08) !important;
			}
			.navbar-header .dropdown-toggle::after {
				display: none !important;
			}
			.navbar-header .dropdown-toggle iconify-icon {
				display: inline-flex;
				align-items: center;
				justify-content: center;
				margin-left: 8px;
				color: #6e6d79;
			}
			.sidebar-menu .submenu-toggle {
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 0.75rem;
			}
			.sidebar-menu .submenu-arrow {
				transition: transform 0.2s ease;
				color: #6e6d79;
			}
			.sidebar-menu .submenu-arrow.rotate-180 {
				transform: rotate(180deg);
			}
			.sidebar-menu .sidebar-submenu {
				list-style: none;
				padding-left: 2.75rem;
				margin: 0.75rem 0 0;
				display: grid;
				gap: 0.35rem;
			}
			.sidebar-menu .sidebar-submenu li a {
				display: flex;
				align-items: center;
				gap: 0.6rem;
				padding: 0.5rem 0.75rem;
				border-radius: 0.75rem;
				color: #6e6d79;
				font-size: 0.95rem;
				transition: background-color 0.2s ease, color 0.2s ease;
			}
			.sidebar-menu .sidebar-submenu li a:hover,
			.sidebar-menu .sidebar-submenu li a.active {
				color: #024550 !important;
				background-color: rgba(2, 69, 80, 0.08);
			}
	</style>
		<?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
		<div class="preloader" id="preloader">
			<div class="loader-book">
				<div class="loader-book-page"></div>
				<div class="loader-book-page"></div>
				<div class="loader-book-page"></div>
			</div>
		</div>

		<aside class="sidebar">
			<button type="button" class="sidebar-close-btn">
				<iconify-icon icon="radix-icons:cross-2"></iconify-icon>
			</button>
			<div class="mb-24">
				<a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar-logo">
					<img src="<?php echo e($siteLogoLight); ?>" alt="logo" class="light-logo" style="width:240px;height:140px;object-fit:contain;">
					<img src="<?php echo e($siteLogoDark); ?>" alt="logo" class="dark-logo" style="width:240px;height:140px;object-fit:contain;">
					<img src="<?php echo e($siteLogoIcon); ?>" alt="logo" class="logo-icon">
				</a>
			</div>
			<div class="sidebar-menu-area">
				<ul class="sidebar-menu" id="sidebar-menu">
					<?php
						$blogMenuActive = request()->routeIs('admin.blog.posts.*') || request()->routeIs('admin.blog.categories.*') || request()->routeIs('admin.blog.tags.*');
						$catalogMenuActive = request()->routeIs('admin.products.*') || request()->routeIs('admin.categories.*') || request()->routeIs('admin.tags.*');
						$settingsMenuActive = request()->routeIs('admin.settings.*') || request()->routeIs('admin.integrations.*');
					?>
					<li class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
						<a href="<?php echo e(route('admin.dashboard')); ?>">
							<iconify-icon icon="solar:home-smile-angle-outline" class="menu-icon"></iconify-icon>
							<span>Dashboard</span>
						</a>
					</li>
					<li class="<?php echo e($catalogMenuActive ? 'active' : ''); ?>">
						<a href="javascript:void(0)"
						   class="submenu-toggle d-flex align-items-center justify-content-between gap-3"
						   data-submenu="catalog"
						   data-bs-toggle="collapse"
						   data-bs-target="#sidebarCatalogMenu"
						   aria-expanded="<?php echo e($catalogMenuActive ? 'true' : 'false'); ?>"
						   aria-controls="sidebarCatalogMenu">
							<span class="d-inline-flex align-items-center gap-3">
								<iconify-icon icon="mdi:store-outline" class="menu-icon"></iconify-icon>
								<span>Catalog</span>
							</span>
							<iconify-icon icon="solar:alt-arrow-down-outline" class="submenu-arrow <?php echo e($catalogMenuActive ? 'rotate-180' : ''); ?>"></iconify-icon>
						</a>
						<ul class="sidebar-submenu collapse <?php echo e($catalogMenuActive ? 'show' : ''); ?>" id="sidebarCatalogMenu">
							<li>
								<a href="<?php echo e(route('admin.products.index')); ?>" class="<?php echo e(request()->routeIs('admin.products.*') ? 'active' : ''); ?>">
									<iconify-icon icon="solar:bag-smile-outline" class="text-primary-main"></iconify-icon>
									Products
								</a>
							</li>
							<li>
								<a href="<?php echo e(route('admin.categories.index')); ?>" class="<?php echo e(request()->routeIs('admin.categories.*') ? 'active' : ''); ?>">
									<iconify-icon icon="solar:menu-dots-vertical-linear" class="text-info-main"></iconify-icon>
									Product Categories
								</a>
							</li>
							<li>
								<a href="<?php echo e(route('admin.tags.index')); ?>" class="<?php echo e(request()->routeIs('admin.tags.*') ? 'active' : ''); ?>">
									<iconify-icon icon="solar:hashtag-linear" class="text-warning"></iconify-icon>
									Product Tags
								</a>
							</li>
						</ul>
					</li>
					<li class="<?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>">
						<a href="<?php echo e(route('admin.users.index')); ?>">
							<iconify-icon icon="solar:user-id-linear" class="menu-icon"></iconify-icon>
							<span>Users</span>
						</a>
					</li>
					<li class="<?php echo e($blogMenuActive ? 'active' : ''); ?>">
						<a href="javascript:void(0)"
						   class="submenu-toggle"
						   data-submenu="blog"
						   data-bs-toggle="collapse"
						   data-bs-target="#sidebarBlogMenu"
						   aria-expanded="<?php echo e($blogMenuActive ? 'true' : 'false'); ?>"
						   aria-controls="sidebarBlogMenu">
							<span class="d-inline-flex align-items-center gap-3">
								<iconify-icon icon="solar:document-text-outline" class="menu-icon"></iconify-icon>
								<span>Blogs</span>
							</span>
							<iconify-icon icon="solar:alt-arrow-down-outline" class="submenu-arrow <?php echo e($blogMenuActive ? 'rotate-180' : ''); ?>"></iconify-icon>
						</a>
						<ul class="sidebar-submenu collapse <?php echo e($blogMenuActive ? 'show' : ''); ?>" id="sidebarBlogMenu">
							<li>
								<a href="<?php echo e(route('admin.blog.posts.index')); ?>" class="<?php echo e(request()->routeIs('admin.blog.posts.*') ? 'active' : ''); ?>">
									<iconify-icon icon="solar:document-add-outline" class="text-primary-main"></iconify-icon>
									All Posts
								</a>
							</li>
							<li>
								<a href="<?php echo e(route('admin.blog.categories.index')); ?>" class="<?php echo e(request()->routeIs('admin.blog.categories.*') ? 'active' : ''); ?>">
									<iconify-icon icon="solar:folders-outline" class="text-info-main"></iconify-icon>
									Categories
								</a>
							</li>
							<li>
								<a href="<?php echo e(route('admin.blog.tags.index')); ?>" class="<?php echo e(request()->routeIs('admin.blog.tags.*') ? 'active' : ''); ?>">
									<iconify-icon icon="solar:hashtag-circle-outline" class="text-warning"></iconify-icon>
									Tags
								</a>
							</li>
						</ul>
					</li>
					<li class="<?php echo e(request()->routeIs('admin.orders.*') ? 'active' : ''); ?>">
						<a href="<?php echo e(route('admin.orders.index')); ?>">
							<iconify-icon icon="mdi:clipboard-text-outline" class="menu-icon"></iconify-icon>
							<span>Orders</span>
						</a>
					</li>
					<li class="<?php echo e(request()->routeIs('admin.support.*') ? 'active' : ''); ?>">
						<a href="<?php echo e(route('admin.support.tickets.index')); ?>">
							<iconify-icon icon="solar:lifebuoy-outline" class="menu-icon"></iconify-icon>
							<span>Support</span>
						</a>
					</li>
					<li>
						<a href="#">
							<iconify-icon icon="solar:users-group-two-rounded-outline" class="menu-icon"></iconify-icon>
							<span>Customers</span>
						</a>
					</li>
					<li>
						<a href="#">
							<iconify-icon icon="solar:bell-outline" class="menu-icon"></iconify-icon>
							<span>Notifications</span>
						</a>
					</li>
					<li class="<?php echo e($settingsMenuActive ? 'active' : ''); ?>">
						<a href="javascript:void(0)"
						   class="submenu-toggle d-flex align-items-center justify-content-between gap-3"
						   data-submenu="settings"
						   data-bs-toggle="collapse"
						   data-bs-target="#sidebarSettingsMenu"
						   aria-expanded="<?php echo e($settingsMenuActive ? 'true' : 'false'); ?>"
						   aria-controls="sidebarSettingsMenu">
							<span class="d-inline-flex align-items-center gap-3">
								<iconify-icon icon="solar:settings-linear" class="menu-icon"></iconify-icon>
								<span>Settings</span>
							</span>
							<iconify-icon icon="solar:alt-arrow-down-outline" class="submenu-arrow <?php echo e($settingsMenuActive ? 'rotate-180' : ''); ?>"></iconify-icon>
						</a>
						<ul class="sidebar-submenu collapse <?php echo e($settingsMenuActive ? 'show' : ''); ?>" id="sidebarSettingsMenu">
							<li>
								<a href="<?php echo e(route('admin.settings.general')); ?>" class="<?php echo e(request()->routeIs('admin.settings.general') ? 'active' : ''); ?>">
									<iconify-icon icon="solar:widget-4-outline" class="text-primary-main"></iconify-icon>
									General
								</a>
							</li>
							<li>
								<a href="<?php echo e(route('admin.settings.seo')); ?>" class="<?php echo e(request()->routeIs('admin.settings.seo*') ? 'active' : ''); ?>">
									<iconify-icon icon="solar:shield-check-outline" class="text-info-main"></iconify-icon>
									SEO Tools
								</a>
							</li>
							<li>
								<a href="<?php echo e(route('admin.integrations.index')); ?>" class="<?php echo e(request()->routeIs('admin.integrations.*') ? 'active' : ''); ?>">
									<iconify-icon icon="solar:usb-outline" class="text-warning"></iconify-icon>
									Integrations
								</a>
							</li>
						</ul>
					</li>
				</ul>
			</div>
			<div class="sidebar-profile">
				<div class="sidebar-profile-top">
					<div class="profile-thumb">
						<img src="<?php echo e($adminAvatar); ?>" alt="profile">
					</div>
					<h6 class="name mb-0"><?php echo e($adminUser?->name ?? 'Admin'); ?></h6>
					<span class="designation">Administrator</span>
				</div>
				<a href="<?php echo e(route('logout')); ?>" class="sidebar-logout" onclick="event.preventDefault(); document.getElementById('admin-logout-form').submit();">
					<iconify-icon icon="solar:logout-2-outline"></iconify-icon>
					<span>Logout</span>
				</a>
				<form id="admin-logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
					<?php echo csrf_field(); ?>
				</form>
			</div>
		</aside>

		<main class="dashboard-main">
			<div class="navbar-header">
				<div class="row align-items-center justify-content-between g-0">
					<div class="col-auto">
						<div class="d-flex flex-wrap align-items-center gap-3">
							<button type="button" class="sidebar-toggle">
								<iconify-icon icon="heroicons:bars-3-solid" class="icon text-2xl non-active"></iconify-icon>
								<iconify-icon icon="iconoir:arrow-right" class="icon text-2xl active"></iconify-icon>
							</button>
							<button type="button" class="sidebar-mobile-toggle">
								<iconify-icon icon="heroicons:bars-3-solid" class="icon"></iconify-icon>
							</button>
							<form class="navbar-search d-none d-md-flex">
								<input type="text" name="search" placeholder="Search">
								<iconify-icon icon="ion:search-outline" class="icon"></iconify-icon>
							</form>
						</div>
					</div>
					<div class="col-auto">
						<div class="d-flex flex-wrap align-items-center gap-3">
							<button class="w-40-px h-40-px bg-neutral-200 rounded-circle d-flex justify-content-center align-items-center" type="button" data-theme-toggle></button>
							<div class="dropdown">
								<button class="has-indicator w-40-px h-40-px bg-neutral-200 rounded-circle d-flex justify-content-center align-items-center" type="button" data-bs-toggle="dropdown">
									<iconify-icon icon="solar:bell-outline" class="text-primary-light text-xl"></iconify-icon>
								</button>
								<div class="dropdown-menu to-top dropdown-menu-lg p-0">
									<div class="m-16 py-12 px-16 radius-8 bg-primary-50 mb-16 d-flex align-items-center justify-content-between gap-2">
										<div>
											<h6 class="text-lg text-primary-light fw-semibold mb-0">Notifications</h6>
										</div>
										<span class="text-primary-600 fw-semibold text-lg w-40-px h-40-px rounded-circle bg-base d-flex justify-content-center align-items-center">3</span>
									</div>
									<div class="max-h-400-px overflow-y-auto scroll-sm pe-4">
										<div class="px-24 py-12 d-flex align-items-start gap-3 mb-2 justify-content-between">
											<div class="d-flex align-items-center gap-3">
												<span class="w-40-px h-40-px rounded-circle flex-shrink-0 bg-success-focus d-flex justify-content-center align-items-center">
													<iconify-icon icon="solar:bag-heart-bold-duotone" class="text-success-main text-xl"></iconify-icon>
												</span>
												<div>
													<h6 class="text-md fw-semibold mb-4">New order received</h6>
													<p class="mb-0 text-sm text-secondary-light">2 mins ago</p>
												</div>
											</div>
										</div>
									</div>
									<a href="#" class="d-block text-center py-12 text-primary-600 fw-semibold border-top">View all alerts</a>
								</div>
							</div>
						<div class="dropdown">
							<button class="btn btn-link text-decoration-none p-0 dropdown-toggle" type="button" data-bs-toggle="dropdown" style="box-shadow:none;background:none;border:0;">
								<img src="<?php echo e($adminAvatar); ?>" alt="avatar" class="w-40-px h-40-px rounded-circle object-fit-cover">
							</button>
							<div class="dropdown-menu dropdown-menu-end profile-dropdown shadow border-0 radius-12 p-0 overflow-hidden">
								<div class="p-24 bg-neutral-100">
									<div class="d-flex align-items-center gap-3">
										<img src="<?php echo e($adminAvatar); ?>" alt="avatar" class="w-56-px h-56-px rounded-circle object-fit-cover">
										<div>
											<h6 class="mb-0 text-md fw-semibold"><?php echo e($adminUser?->name ?? 'Admin'); ?></h6>
											<span class="text-sm text-secondary-light"><?php echo e($adminUser?->email ?? 'admin@example.com'); ?></span>
										</div>
									</div>
								</div>
								<div class="list-group list-group-flush">
									<a href="<?php echo e(route('admin.profile')); ?>" class="list-group-item list-group-item-action d-flex align-items-center gap-2">
										<iconify-icon icon="solar:user-circle-outline" class="text-lg"></iconify-icon>
										View Profile
									</a>
									<a href="<?php echo e(route('admin.settings.general')); ?>" class="list-group-item list-group-item-action d-flex align-items-center gap-2">
										<iconify-icon icon="solar:settings-outline" class="text-lg"></iconify-icon>
										Settings
									</a>
								</div>
								<div class="border-top">
									<a class="dropdown-item text-danger py-12 d-flex align-items-center gap-2" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('admin-logout-form').submit();">
										<iconify-icon icon="solar:logout-2-outline" class="text-lg"></iconify-icon>
										Logout
									</a>
								</div>
							</div>
						</div>
						</div>
					</div>
				</div>
			</div>

				<?php echo $__env->yieldContent('content'); ?>

			<footer class="footer mt-32">
				<div class="container-fluid">
					<div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
						<p class="mb-0">&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All rights reserved.</p>
						<div class="d-flex gap-3">
							<a href="#" class="text-secondary-light">Privacy Policy</a>
							<a href="#" class="text-secondary-light">Terms</a>
							<a href="#" class="text-secondary-light">Help</a>
						</div>
		</div>
	</div>
			</footer>
		</main>

		<script src="<?php echo e(asset('wowdash/assets/js/lib/jquery-3.7.1.min.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/bootstrap.bundle.min.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/apexcharts.min.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/dataTables.min.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/iconify-icon.min.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/jquery-ui.min.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/jquery-jvectormap-2.0.5.min.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/jquery-jvectormap-world-mill-en.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/magnifc-popup.min.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/slick.min.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/prism.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/file-upload.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/lib/audioplayer.js')); ?>"></script>
		<script src="<?php echo e(asset('wowdash/assets/js/app.js')); ?>"></script>
		<script>
			document.addEventListener('DOMContentLoaded', function () {
				if (typeof bootstrap === 'undefined') {
					return;
				}

				const setupSubmenu = (toggle) => {
					const menuId = toggle.getAttribute('data-bs-target')?.replace('#', '');
					if (!menuId) {
						return null;
					}
					const menu = document.getElementById(menuId);
					if (!menu) {
						return null;
					}

					const arrow = toggle.querySelector('.submenu-arrow');
					const collapseInstance = bootstrap.Collapse.getOrCreateInstance(menu, { toggle: false });

					const setExpanded = (expanded) => {
						toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
						if (expanded) {
							arrow?.classList.add('rotate-180');
							toggle.classList.add('active');
							menu.style.height = '';
							menu.style.display = '';
							menu.classList.add('show');
						} else {
							arrow?.classList.remove('rotate-180');
							const stayActive = toggle.dataset.submenu === 'blog'
								? <?php echo json_encode($blogMenuActive, 15, 512) ?>
								: (toggle.dataset.submenu === 'catalog' ? <?php echo json_encode($catalogMenuActive, 15, 512) ?> : false);
							if (!stayActive) {
								toggle.classList.remove('active');
							}
							menu.classList.remove('show', 'collapsing');
							menu.style.height = '';
							menu.style.display = 'none';
						}
					};

					if (menu.classList.contains('show')) {
						setExpanded(true);
					} else {
						setExpanded(false);
					}

					const forceCollapse = () => {
						try {
							collapseInstance.hide();
						} catch (e) {
							/* ignore */
						}
						setExpanded(false);
					};

					menu.addEventListener('shown.bs.collapse', () => setExpanded(true));
					menu.addEventListener('hidden.bs.collapse', () => setExpanded(false));

					toggle.addEventListener('click', (event) => {
						event.preventDefault();
						const isExpanded = menu.classList.contains('show') || menu.style.display === '';
						if (isExpanded) {
							forceCollapse();
						} else {
							setExpanded(true);
							try {
								collapseInstance.show();
							} catch (e) {
								menu.classList.add('show');
								menu.style.display = '';
							}
						}
					});

					return { toggle, menu, forceCollapse };
				};

				const submenuConfigs = Array.from(document.querySelectorAll('.submenu-toggle'))
					.map(setupSubmenu)
					.filter(Boolean);

				document.querySelectorAll('#sidebar-menu > li > a').forEach((link) => {
					link.addEventListener('click', function () {
						submenuConfigs.forEach(({ forceCollapse }) => forceCollapse());
					});
				});
			});
		</script>
		<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\ecom123\resources\views/layouts/admin.blade.php ENDPATH**/ ?>