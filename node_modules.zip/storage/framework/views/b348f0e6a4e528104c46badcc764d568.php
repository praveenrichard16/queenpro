

<?php $__env->startSection('title', 'Shopping Cart'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="<?php echo e(route('home')); ?>">Home</a></span>
                <span class="devider">/</span>
                <span>Shopping Cart</span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up">Your Cart</h1>
                <p class="text-muted mt-2" data-aos="fade-up" data-aos-delay="100">
                    Review your selections, update quantities, or continue browsing to add more.
                </p>
            </div>
        </div>
    </section>

    <section class="product cart">
        <div class="container">
            <?php if(count($cart) > 0): ?>
                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="cart-wrapper" data-aos="fade-up">
                            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="cart-item d-flex flex-column flex-md-row align-items-md-center gap-4">
                                    <div class="cart-img">
                                        <img src="<?php echo e($item['image'] ?: asset('shopus/assets/images/homepage-one/product-img/product-img-4.webp')); ?>" alt="<?php echo e($item['name']); ?>">
                                    </div>
                                    <div class="cart-details flex-fill">
                                        <h5 class="cart-title mb-1"><?php echo e($item['name']); ?></h5>
                                        <p class="text-muted small mb-2">Max available: <?php echo e($item['max_quantity']); ?></p>
                                        <div class="d-flex flex-wrap align-items-center gap-3">
                                            <span class="cart-price"><?php echo e(number_format($item['price'], 2)); ?> AED</span>
                                            <form action="<?php echo e(route('cart.update')); ?>" method="POST" class="d-flex align-items-center gap-2">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="product_id" value="<?php echo e($item['id']); ?>">
                                                <input type="number" name="quantity" class="form-control" value="<?php echo e($item['quantity']); ?>" min="1" max="<?php echo e($item['max_quantity']); ?>">
                                                <button type="submit" class="shop-btn view-btn">Update</button>
                                            </form>
                                            <form action="<?php echo e(route('cart.remove')); ?>" method="POST" onsubmit="return confirm('Remove this item?')">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="product_id" value="<?php echo e($item['id']); ?>">
                                                <button type="submit" class="shop-btn view-btn text-danger">Remove</button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="cart-total text-md-end">
                                        <span class="text-muted small">Line total</span>
                                        <h6 class="mb-0"><?php echo e(number_format($item['price'] * $item['quantity'], 2)); ?> AED</h6>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="d-flex flex-wrap justify-content-between align-items-center mt-4 gap-3" data-aos="fade-up">
                            <a href="<?php echo e(route('products.index')); ?>" class="shop-btn view-btn">Continue Shopping</a>
                            <form action="<?php echo e(route('cart.clear')); ?>" method="POST" onsubmit="return confirm('Clear your cart?')" class="mb-0">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="shop-btn text-danger">Clear Cart</button>
                            </form>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <aside class="cart-summary" data-aos="fade-left">
                            <h5>Order Summary</h5>
                            <div class="summary-line d-flex justify-content-between">
                                <span>Subtotal</span>
                                <span><?php echo e(number_format($total, 2)); ?> AED</span>
                            </div>
                            <div class="summary-line d-flex justify-content-between">
                                <span>Shipping</span>
                                <span class="text-success">Complimentary</span>
                            </div>
                            <hr>
                            <div class="summary-line total d-flex justify-content-between">
                                <strong>Total</strong>
                                <strong><?php echo e(number_format($total, 2)); ?> AED</strong>
                            </div>
                            <a href="<?php echo e(route('checkout')); ?>" class="shop-btn checkout-btn w-100 mt-4">Proceed to Checkout</a>
                            <div class="security-badges mt-4">
                                <p class="small text-muted mb-2">Secure payment with:</p>
                                <div class="d-flex gap-3 align-items-center">
                                    <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-1.png')); ?>" alt="Visa">
                                    <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-2.png')); ?>" alt="Mastercard">
                                    <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-3.png')); ?>" alt="PayPal">
                                </div>
                            </div>
                        </aside>
                    </div>
                </div>
            <?php else: ?>
                <div class="empty-state text-center" data-aos="fade-up">
                    <img src="<?php echo e(asset('shopus/assets/images/homepage-one/empty-cart.webp')); ?>" alt="Empty cart" class="mb-4" style="max-width: 320px;">
                    <h4>Your cart is empty</h4>
                    <p class="text-muted">Browse our latest drops and add items to your bag.</p>
                    <a href="<?php echo e(route('products.index')); ?>" class="shop-btn mt-3">Start Shopping</a>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/cart/index.blade.php ENDPATH**/ ?>