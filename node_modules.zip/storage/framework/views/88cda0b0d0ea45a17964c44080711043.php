

<?php $__env->startSection('title', 'Wishlist'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="<?php echo e(route('home')); ?>">Home</a></span>
                <span class="devider">/</span>
                <span>Wishlist</span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up">Your Wishlist</h1>
                <p class="text-muted mt-2" data-aos="fade-up" data-aos-delay="100">
                    Save favourites to revisit later. Sign in to sync across all your devices.
                </p>
            </div>
        </div>
    </section>

    <section class="product wishlist">
        <div class="container">
            <div class="wishlist-section" data-aos="fade-up">
                <div class="empty-state text-center">
                    <img src="<?php echo e(asset('shopus/assets/images/homepage-one/empty-wishlist.webp')); ?>" alt="Empty wishlist" class="mb-4" style="max-width: 320px;">
                    <h4>Your wishlist is feeling lonely</h4>
                    <p class="text-muted">Tap the heart icon on any product to add it here and keep track of looks you love.</p>
                    <div class="d-flex justify-content-center gap-3 mt-4">
                        <a href="<?php echo e(route('products.index')); ?>" class="shop-btn">Shop New Arrivals</a>
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(route('customer.dashboard')); ?>" class="shop-btn view-btn">Go to Dashboard</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="shop-btn view-btn">Sign In</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/pages/wishlist.blade.php ENDPATH**/ ?>