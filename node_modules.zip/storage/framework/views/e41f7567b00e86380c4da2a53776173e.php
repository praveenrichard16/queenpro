

<?php $__env->startSection('title', 'About Us'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="<?php echo e(route('home')); ?>">Home</a></span>
                <span class="devider">/</span>
                <span>About Us</span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up">About <?php echo e(config('app.name')); ?></h1>
                <p class="text-muted mt-3" data-aos="fade-up" data-aos-delay="100">
                    Inspired by the energy of Dubai, we curate global trends and timeless classics for modern shoppers.
                </p>
            </div>
        </div>
    </section>

    <section class="about">
        <div class="container">
            <div class="about-section">
                <div class="row align-items-center gy-5">
                    <div class="col-lg-6">
                        <div class="about-img" data-aos="fade-right">
                            <img src="<?php echo e(asset('shopus/assets/images/homepage-one/about/about-img-1.webp')); ?>" alt="About <?php echo e(config('app.name')); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-content" data-aos="fade-left">
                            <h3 class="about-title">Elevating Lifestyle Experiences</h3>
                            <p class="about-info">
                                We believe shopping should be simple, inspiring, and trustworthy. Our team scouts the world for boutique designers and
                                established brands, delivering fresh collections and everyday essentials straight to your door across the UAE.
                            </p>
                            <div class="about-list">
                                <ul>
                                    <li>
                                        <span>
                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <circle cx="12.5" cy="12.5" r="12.5" fill="#AE1C9A" />
                                                <path d="M10.169 13.2566C10.5171 12.8649 10.8497 12.4803 11.1979 12.1029C12.776 10.3864 14.4972 8.80535 16.4698 7.47353C16.6748 7.33465 16.8875 7.20289 17.1041 7.0747C17.1738 7.03552 17.2627 7.00347 17.3439 7.00347C17.7887 6.99635 18.2336 6.99991 18.6745 6.99991C18.8137 6.99991 18.9259 7.04265 18.9762 7.16728C19.0265 7.28836 18.9878 7.39163 18.8834 7.48065C17.0771 8.99765 15.5879 10.7639 14.1723 12.5872C12.8688 14.2644 11.662 16.0022 10.5287 17.7863C10.49 17.8504 10.4397 17.918 10.374 17.9572C10.2347 18.0462 10.0762 17.9964 9.97176 17.8432C9.7977 17.5868 9.63525 17.3233 9.44959 17.074C8.36271 15.6318 7.2681 14.1896 6.17735 12.751C6.13481 12.6976 6.08839 12.6441 6.04971 12.5872C5.97236 12.4732 5.97622 12.3486 6.07679 12.256C6.36688 11.9853 6.66471 11.7147 6.96254 11.4476C7.07857 11.3444 7.20235 11.3515 7.35706 11.4476C7.83668 11.7539 8.3163 12.0637 8.79205 12.3699C9.24846 12.6655 9.70488 12.9575 10.169 13.2566Z" fill="white" />
                                            </svg>
                                        </span>
                                        <p>Curated designer and emerging labels sourced responsibly.</p>
                                    </li>
                                    <li>
                                        <span>
                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <circle cx="12.5" cy="12.5" r="12.5" fill="#AE1C9A" />
                                                <path d="M10.169 13.2566C10.5171 12.8649 10.8497 12.4803 11.1979 12.1029C12.776 10.3864 14.4972 8.80535 16.4698 7.47353C16.6748 7.33465 16.8875 7.20289 17.1041 7.0747C17.1738 7.03552 17.2627 7.00347 17.3439 7.00347C17.7887 6.99635 18.2336 6.99991 18.6745 6.99991C18.8137 6.99991 18.9259 7.04265 18.9762 7.16728C19.0265 7.28836 18.9878 7.39163 18.8834 7.48065C17.0771 8.99765 15.5879 10.7639 14.1723 12.5872C12.8688 14.2644 11.662 16.0022 10.5287 17.7863C10.49 17.8504 10.4397 17.918 10.374 17.9572C10.2347 18.0462 10.0762 17.9964 9.97176 17.8432C9.7977 17.5868 9.63525 17.3233 9.44959 17.074C8.36271 15.6318 7.2681 14.1896 6.17735 12.751C6.13481 12.6976 6.08839 12.6441 6.04971 12.5872C5.97236 12.4732 5.97622 12.3486 6.07679 12.256C6.36688 11.9853 6.66471 11.7147 6.96254 11.4476C7.07857 11.3444 7.20235 11.3515 7.35706 11.4476C7.83668 11.7539 8.3163 12.0637 8.79205 12.3699C9.24846 12.6655 9.70488 12.9575 10.169 13.2566Z" fill="white" />
                                            </svg>
                                        </span>
                                        <p>Fast fulfilment from our Dubai hub with tracked delivery.</p>
                                    </li>
                                    <li>
                                        <span>
                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <circle cx="12.5" cy="12.5" r="12.5" fill="#AE1C9A" />
                                                <path d="M10.169 13.2566C10.5171 12.8649 10.8497 12.4803 11.1979 12.1029C12.776 10.3864 14.4972 8.80535 16.4698 7.47353C16.6748 7.33465 16.8875 7.20289 17.1041 7.0747C17.1738 7.03552 17.2627 7.00347 17.3439 7.00347C17.7887 6.99635 18.2336 6.99991 18.6745 6.99991C18.8137 6.99991 18.9259 7.04265 18.9762 7.16728C19.0265 7.28836 18.9878 7.39163 18.8834 7.48065C17.0771 8.99765 15.5879 10.7639 14.1723 12.5872C12.8688 14.2644 11.662 16.0022 10.5287 17.7863C10.49 17.8504 10.4397 17.918 10.374 17.9572C10.2347 18.0462 10.0762 17.9964 9.97176 17.8432C9.7977 17.5868 9.63525 17.3233 9.44959 17.074C8.36271 15.6318 7.2681 14.1896 6.17735 12.751C6.13481 12.6976 6.08839 12.6441 6.04971 12.5872C5.97236 12.4732 5.97622 12.3486 6.07679 12.256C6.36688 11.9853 6.66471 11.7147 6.96254 11.4476C7.07857 11.3444 7.20235 11.3515 7.35706 11.4476C7.83668 11.7539 8.3163 12.0637 8.79205 12.3699C9.24846 12.6655 9.70488 12.9575 10.169 13.2566Z" fill="white" />
                                            </svg>
                                        </span>
                                        <p>Dedicated stylists and concierge support whenever you need.</p>
                                    </li>
                                </ul>
                            </div>
                            <a href="<?php echo e(route('contact')); ?>" class="shop-btn">
                                Contact us
                                <span>
                                    <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect x="1.45312" y="0.914062" width="9.25346" height="2.05632" transform="rotate(45 1.45312 0.914062)" fill="white" />
                                        <rect x="8" y="7.45703" width="9.25346" height="2.05632" transform="rotate(135 8 7.45703)" fill="white" />
                                    </svg>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="about-service product">
        <div class="container">
            <div class="about-service-section">
                <div class="about-wrapper" data-aos="fade-up">
                    <div class="wrapper-img">
                        <span>
                            <img src="<?php echo e(asset('shopus/assets/images/homepage-one/icon.png')); ?>" alt="Mission">
                        </span>
                    </div>
                    <div class="wrapper-info">
                        <h5 class="wrapper-details about-details">Our Mission</h5>
                        <p>
                            To blend global fashion with regional flair, while delivering an effortless shopping journey powered by data,
                            sustainability, and heartfelt service.
                        </p>
                    </div>
                </div>
                <div class="about-wrapper" data-aos="fade-up" data-aos-delay="100">
                    <div class="wrapper-img">
                        <span>
                            <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-4.png')); ?>" alt="Vision">
                        </span>
                    </div>
                    <div class="wrapper-info">
                        <h5 class="wrapper-details about-details">Our Vision</h5>
                        <p>
                            Build the most loved digital fashion destination in the Middle East—one that celebrates individuality, culture, and innovation.
                        </p>
                    </div>
                </div>
                <div class="about-wrapper" data-aos="fade-up" data-aos-delay="200">
                    <div class="wrapper-img">
                        <span>
                            <img src="<?php echo e(asset('shopus/assets/images/homepage-one/payment-img-3.png')); ?>" alt="Values">
                        </span>
                    </div>
                    <div class="wrapper-info">
                        <h5 class="wrapper-details about-details">What Drives Us</h5>
                        <p>
                            Passion for design, respect for craftsmanship, and a relentless commitment to customer happiness.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/pages/about.blade.php ENDPATH**/ ?>