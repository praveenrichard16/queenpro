

<?php $__env->startSection('title', 'Privacy Policy'); ?>

<?php
    $updatedAt = now()->format('F j, Y');
?>

<?php $__env->startSection('content'); ?>
    <section class="blog about-blog">
        <div class="container">
            <div class="blog-bradcrum">
                <span><a href="<?php echo e(route('home')); ?>">Home</a></span>
                <span class="devider">/</span>
                <span>Privacy Policy</span>
            </div>
            <div class="blog-heading about-heading">
                <h1 class="heading" data-aos="fade-up">Privacy Policy</h1>
                <p class="text-muted mt-2" data-aos="fade-up" data-aos-delay="100">
                    We are committed to protecting your personal information and transparency across every interaction.
                </p>
            </div>
        </div>
    </section>

    <section class="product policy">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <article class="policy-wrapper" data-aos="fade-up">
                        <p class="small text-muted text-end">Last updated: <?php echo e($updatedAt); ?></p>

                        <h5>1. Overview</h5>
                        <p>
                            This policy explains how <?php echo e(config('app.name')); ?> (“we”, “us”, “our”) collects, uses, and safeguards your information
                            when you browse our website or shop through our digital channels. By accessing our services you consent to the practices
                            outlined below.
                        </p>

                        <h5>2. Data We Collect</h5>
                        <ul>
                            <li>Account details such as name, email address, delivery location, and contact number.</li>
                            <li>Payment and transaction information processed securely through trusted gateways.</li>
                            <li>Browsing behaviour, device identifiers, and analytics data captured via cookies.</li>
                        </ul>

                        <h5>3. How We Use Your Information</h5>
                        <p>
                            We use collected data to fulfil orders, provide personalised recommendations, improve site performance, prevent fraud,
                            and communicate important updates or promotions you opt into.
                        </p>

                        <h5>4. Sharing &amp; Third Parties</h5>
                        <p>
                            We never sell your personal data. Information is shared only with logistics partners, payment processors, or technology
                            providers who enable core services and comply with strict confidentiality obligations.
                        </p>

                        <h5>5. Your Rights</h5>
                        <p>
                            You may request access, correction, or deletion of the personal data we hold about you. You can also withdraw marketing
                            consent at any time using the unsubscribe links within our communications.
                        </p>

                        <h5>6. Contact</h5>
                        <p>
                            Questions? Email <a href="mailto:privacy{{ Str::slug(config('app.name'), '') }}.com">privacy{{ Str::slug(config('app.name'), '') }}.com</a> or reach our compliance team through the
                            <a href="<?php echo e(route('contact')); ?>">contact page</a>.
                        </p>
                    </article>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/pages/privacy.blade.php ENDPATH**/ ?>