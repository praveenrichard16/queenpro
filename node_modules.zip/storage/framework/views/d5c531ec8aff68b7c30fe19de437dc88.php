

<?php $__env->startSection('title', $category->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
	<h2 class="mb-0"><?php echo e($category->name); ?></h2>
	<a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-secondary">All Products</a>
</div>

<?php if($products->count() > 0): ?>
	<div class="row">
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-3 col-md-4 col-sm-6 mb-4">
				<div class="card h-100 shadow-sm">
					<?php if($product->image): ?>
						<img src="<?php echo e($product->image); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>" style="height: 200px; object-fit: cover;">
					<?php else: ?>
						<img src="https://via.placeholder.com/300x200/6c757d/ffffff?text=No+Image" class="card-img-top" alt="<?php echo e($product->name); ?>" style="height: 200px; object-fit: cover;">
					<?php endif; ?>
					<div class="card-body d-flex flex-column">
						<h6 class="card-title"><?php echo e($product->name); ?></h6>
						<p class="card-text text-muted small">$<?php echo e(number_format($product->price, 2)); ?></p>
						<div class="mt-auto d-grid gap-2">
							<a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-outline-primary btn-sm">View</a>
							<form action="<?php echo e(route('cart.add')); ?>" method="POST" class="d-inline">
								<?php echo csrf_field(); ?>
								<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
								<input type="hidden" name="quantity" value="1">
								<button type="submit" class="btn btn-primary btn-sm" <?php echo e($product->stock_quantity <= 0 ? 'disabled' : ''); ?>>
									Add to Cart
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<div class="d-flex justify-content-center">
		<?php echo e($products->links()); ?>

	</div>
<?php else: ?>
	<div class="text-center py-5">
		<i class="fas fa-search fa-3x text-muted mb-3"></i>
		<h4>No products found in this category</h4>
		<a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary mt-2">Browse All Products</a>
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecom123\resources\views/products/category.blade.php ENDPATH**/ ?>