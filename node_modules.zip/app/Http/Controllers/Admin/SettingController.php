<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class SettingController extends Controller
{
    public function edit(): View
    {
        $settings = collect([
            'site_name' => Setting::getValue('site_name', config('app.name')),
            'site_tagline' => Setting::getValue('site_tagline'),
            'contact_email' => Setting::getValue('contact_email'),
            'contact_phone' => Setting::getValue('contact_phone'),
            'contact_street' => Setting::getValue('contact_street'),
            'contact_city' => Setting::getValue('contact_city'),
            'contact_state' => Setting::getValue('contact_state'),
            'contact_postal' => Setting::getValue('contact_postal'),
            'contact_country' => Setting::getValue('contact_country'),
            'site_logo' => Setting::getValue('site_logo'),
            'site_logo_dark' => Setting::getValue('site_logo_dark'),
            'site_favicon' => Setting::getValue('site_favicon'),
            'google_analytics_id' => Setting::getValue('google_analytics_id'),
            'google_tag_manager_id' => Setting::getValue('google_tag_manager_id'),
            'google_search_console_verification' => Setting::getValue('google_search_console_verification'),
        ]);

        return view('admin.settings.general', [
            'settings' => $settings,
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'site_name' => ['required', 'string', 'max:255'],
            'site_tagline' => ['nullable', 'string', 'max:255'],
            'contact_email' => ['nullable', 'email', 'max:255'],
            'contact_phone' => ['nullable', 'string', 'max:255'],
            'contact_street' => ['nullable', 'string', 'max:255'],
            'contact_city' => ['nullable', 'string', 'max:255'],
            'contact_state' => ['nullable', 'string', 'max:255'],
            'contact_postal' => ['nullable', 'string', 'max:64'],
            'contact_country' => ['nullable', 'string', 'max:255'],
            'site_logo' => ['nullable', 'image', 'max:2048'],
            'site_logo_dark' => ['nullable', 'image', 'max:2048'],
            'site_favicon' => ['nullable', 'image', 'max:1024'],
            'google_analytics_id' => ['nullable', 'string', 'max:255'],
            'google_tag_manager_id' => ['nullable', 'string', 'max:255'],
            'google_search_console_verification' => ['nullable', 'string'],
        ]);

        $uploadKeys = ['site_logo', 'site_logo_dark', 'site_favicon'];
        foreach ($uploadKeys as $fileKey) {
            if ($request->hasFile($fileKey)) {
                $path = $request->file($fileKey)->store('settings', 'public');
                Setting::setValue($fileKey, $path);
            }
        }

        foreach (collect($validated)->except($uploadKeys) as $key => $value) {
            Setting::setValue($key, $value);
        }

        return back()->with('success', 'Settings updated successfully.');
    }
}

