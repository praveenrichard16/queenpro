<?php

namespace App\Http\Controllers\Admin;

use App\Enums\TicketPriority;
use App\Enums\TicketStatus;
use App\Http\Controllers\Controller;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class SupportTicketController extends Controller
{
    public function index(Request $request): View
    {
        $filters = $request->validate([
            'status' => ['nullable', 'string'],
            'priority' => ['nullable', 'string'],
            'assignee' => ['nullable', 'integer'],
            'search' => ['nullable', 'string'],
        ]);

        $query = Ticket::query()
            ->with(['customer:id,name,email', 'assignee:id,name', 'category:id,name'])
            ->latest();

        if (!empty($filters['status']) && in_array($filters['status'], TicketStatus::values(), true)) {
            $query->where('status', $filters['status']);
        }

        if (!empty($filters['priority']) && in_array($filters['priority'], TicketPriority::values(), true)) {
            $query->where('priority', $filters['priority']);
        }

        if (!empty($filters['assignee'])) {
            $query->where('assigned_to', $filters['assignee']);
        }

        if (!empty($filters['search'])) {
            $search = $filters['search'];
            $query->where(function ($builder) use ($search): void {
                $builder->where('ticket_number', 'like', "%{$search}%")
                    ->orWhere('subject', 'like', "%{$search}%");
            });
        }

        $tickets = $query->paginate(15)->withQueryString();

        $statusCounts = $this->statusCounts();

        $assignees = Ticket::query()
            ->select('assigned_to')
            ->whereNotNull('assigned_to')
            ->with('assignee:id,name')
            ->get()
            ->pluck('assignee')
            ->filter()
            ->unique('id')
            ->values();

        return view('admin.tickets.index', [
            'tickets' => $tickets,
            'filters' => $filters,
            'statusCounts' => $statusCounts,
            'statuses' => TicketStatus::cases(),
            'priorities' => TicketPriority::cases(),
            'assignees' => $assignees,
        ]);
    }

    public function show(Ticket $ticket): View
    {
        $ticket->load([
            'customer:id,name,email',
            'assignee:id,name,email',
            'category:id,name',
            'sla:id,name,response_minutes,resolution_minutes',
            'messages' => fn ($query) => $query->with(['author:id,name,email', 'attachments'])->orderBy('created_at'),
        ]);

        return view('admin.tickets.show', [
            'ticket' => $ticket,
            'statuses' => TicketStatus::cases(),
            'priorities' => TicketPriority::cases(),
        ]);
    }

    protected function statusCounts(): Collection
    {
        return Ticket::query()
            ->select('status', DB::raw('count(*) as aggregate'))
            ->groupBy('status')
            ->pluck('aggregate', 'status');
    }
}

