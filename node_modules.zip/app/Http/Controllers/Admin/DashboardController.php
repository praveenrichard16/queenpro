<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
	public function index(Request $request)
	{
		$from = $request->query('from') ? Carbon::parse($request->query('from'))->startOfDay() : Carbon::now()->startOfMonth();
		$to = $request->query('to') ? Carbon::parse($request->query('to'))->endOfDay() : Carbon::now()->endOfMonth();

		$totalSales = Order::whereBetween('created_at', [$from, $to])->sum('total_amount');
		$totalOrders = Order::whereBetween('created_at', [$from, $to])->count();
		totalCustomers:
		$totalCustomers = User::count();
		totalProducts:
		$totalProducts = Product::count();

		$salesSeries = Order::select(DB::raw('DATE(created_at) as d'), DB::raw('SUM(total_amount) as total'))
			->whereBetween('created_at', [$from, $to])
			->groupBy('d')
			->orderBy('d')
			->get();

		$ordersSummary = [
			'delivered' => Order::where('status', 'delivered')->whereBetween('created_at', [$from, $to])->count(),
			'cancelled' => Order::where('status', 'cancelled')->whereBetween('created_at', [$from, $to])->count(),
			'rejected' => Order::where('status', 'rejected')->whereBetween('created_at', [$from, $to])->count(),
			'pending' => Order::where('status', 'pending')->whereBetween('created_at', [$from, $to])->count(),
		];

		$topProducts = OrderItem::select('product_id', DB::raw('SUM(quantity) as qty'))
			->groupBy('product_id')
			->orderByDesc('qty')
			->with('product')
			->limit(8)
			->get();

		$topCustomers = Order::select('customer_email', 'customer_name', DB::raw('COUNT(*) as orders'))
			->groupBy('customer_email', 'customer_name')
			->orderByDesc('orders')
			->limit(8)
			->get();

		return view('admin.dashboard', compact(
			'from', 'to', 'totalSales', 'totalOrders', 'totalCustomers', 'totalProducts', 'salesSeries', 'ordersSummary', 'topProducts', 'topCustomers'
		));
	}
}
