<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Models\Tag;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ProductController extends Controller
{
	public function index(Request $request)
	{
		$query = Product::query()->with('category');

		if ($request->filled('search')) {
			$term = $request->get('search');
			$query->where(function($q) use ($term) {
				$q->where('name', 'like', "%$term%")->orWhere('description', 'like', "%$term%");
			});
		}

		if ($request->filled('category')) {
			$query->where('category_id', $request->get('category'));
		}

		if ($request->filled('status')) {
			$query->where('is_active', $request->boolean('status'));
		}

		$products = $query->orderBy('created_at', 'desc')->paginate(10)->appends($request->query());
		$categories = Category::orderBy('name')->get();

		return view('admin/products/index', compact('products', 'categories'));
	}

	protected function categoryOptions(): array
	{
		$categories = Category::with('children.children')->orderBy('name')->get();
		$root = $categories->whereNull('parent_id');

		$options = [];

		$walker = function ($items, $depth = 0) use (&$walker, &$options) {
			foreach ($items as $item) {
				$options[$item->id] = str_repeat('— ', $depth) . $item->name;
				if ($item->children->isNotEmpty()) {
					$walker($item->children, $depth + 1);
				}
			}
		};

		$walker($root);

		return $options;
	}

	public function create()
	{
		$categories = $this->categoryOptions();
		$tags = Tag::orderBy('name')->get();
		$product = new Product();
		return view('admin/products/form', compact('product', 'categories', 'tags'));
	}

	public function store(Request $request)
	{
		$data = $request->validate([
			'name' => ['required', 'string', 'max:255'],
			'description' => ['nullable', 'string'],
			'price' => ['required', 'numeric', 'min:0'],
			'category_id' => ['required', 'exists:categories,id'],
			'stock_quantity' => ['required', 'integer', 'min:0'],
			'is_active' => ['sometimes', 'boolean'],
			'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
			'tags' => ['nullable', 'array'],
			'tags.*' => ['exists:tags,id'],
			'gallery' => ['nullable', 'array'],
			'gallery.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
		]);

		if ($request->hasFile('image')) {
			$path = $request->file('image')->store('products', 'public');
			$data['image'] = Storage::url($path);
		}

		$data['slug'] = Str::slug($data['name']).'-'.Str::random(4);
		$data['is_active'] = $request->boolean('is_active');

		$product = Product::create($data);
		$product->tags()->sync($request->input('tags', []));

		if ($request->hasFile('gallery')) {
			foreach ($request->file('gallery') as $index => $galleryImage) {
				$path = $galleryImage->store('products/gallery', 'public');
				$product->images()->create([
					'path' => Storage::url($path),
					'position' => $index,
				]);
			}
		}

		return redirect()->route('admin.products.index')->with('success', 'Product created');
	}

	public function edit(Product $product)
	{
		$product->load('images', 'tags');
		$categories = $this->categoryOptions();
		$tags = Tag::orderBy('name')->get();
		return view('admin/products/form', compact('product', 'categories', 'tags'));
	}

	public function update(Request $request, Product $product)
	{
		$data = $request->validate([
			'name' => ['required', 'string', 'max:255'],
			'description' => ['nullable', 'string'],
			'price' => ['required', 'numeric', 'min:0'],
			'category_id' => ['required', 'exists:categories,id'],
			'stock_quantity' => ['required', 'integer', 'min:0'],
			'is_active' => ['sometimes', 'boolean'],
			'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
			'tags' => ['nullable', 'array'],
			'tags.*' => ['exists:tags,id'],
			'gallery' => ['nullable', 'array'],
			'gallery.*' => ['image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
		]);

		if ($request->hasFile('image')) {
			$path = $request->file('image')->store('products', 'public');
			$data['image'] = Storage::url($path);
		}

		$data['is_active'] = $request->boolean('is_active');

		// If name changed, refresh slug minimally
		if ($product->name !== $data['name']) {
			$data['slug'] = Str::slug($data['name']).'-'.Str::random(4);
		}

		$product->update($data);
		$product->tags()->sync($request->input('tags', []));

		if ($request->hasFile('gallery')) {
			$position = (int) $product->images()->max('position') + 1;
			foreach ($request->file('gallery') as $galleryImage) {
				$path = $galleryImage->store('products/gallery', 'public');
				$product->images()->create([
					'path' => Storage::url($path),
					'position' => $position++,
				]);
			}
		}

		return redirect()->route('admin.products.index')->with('success', 'Product updated');
	}

	public function destroyImage(Product $product, \App\Models\ProductImage $image): RedirectResponse
	{
		if ($image->product_id !== $product->id) {
			abort(404);
		}

		if ($image->path) {
			$relative = ltrim(str_replace('/storage/', '', $image->path), '/');
			Storage::disk('public')->delete($relative);
		}

		$image->delete();

		return back()->with('success', 'Image removed successfully.');
	}

	public function destroy(Product $product)
	{
		$product->delete();
		return redirect()->route('admin.products.index')->with('success', 'Product deleted');
	}

	public function export(): StreamedResponse
	{
		$filename = 'products-' . now()->format('Ymd-His') . '.csv';
		$headers = [
			'Content-Type' => 'text/csv',
			'Content-Disposition' => "attachment; filename=\"{$filename}\"",
		];

		$columns = ['name', 'description', 'price', 'category', 'stock_quantity', 'is_active'];

		$callback = function () use ($columns) {
			$handle = fopen('php://output', 'w');
			fputcsv($handle, $columns);

			Product::with('category')
				->orderBy('name')
				->chunk(200, function ($products) use ($handle) {
					foreach ($products as $product) {
						fputcsv($handle, [
							$product->name,
							$product->description,
							$product->price,
							optional($product->category)->name,
							$product->stock_quantity,
							$product->is_active ? 1 : 0,
						]);
					}
				});

			fclose($handle);
		};

		return response()->stream($callback, 200, $headers);
	}

	public function import(Request $request): RedirectResponse
	{
		$data = $request->validate([
			'file' => ['required', 'file', 'mimes:csv,txt'],
		]);

		$path = $data['file']->getRealPath();
		$handle = fopen($path, 'r');

		if ($handle === false) {
			return back()->with('error', 'Unable to read the uploaded file.');
		}

		$header = fgetcsv($handle);
		$expected = ['name', 'description', 'price', 'category', 'stock_quantity', 'is_active'];
		if (!$header || array_map('strtolower', $header) !== $expected) {
			fclose($handle);
			return back()->with('error', 'Invalid CSV format. Expected headers: ' . implode(', ', $expected));
		}

		$created = 0;
		$updated = 0;

		while (($row = fgetcsv($handle)) !== false) {
			[$name, $description, $price, $categoryName, $stock, $isActive] = $row;
			if (blank($name)) {
				continue;
			}

			$category = null;
			if ($categoryName) {
				$category = Category::firstOrCreate(['name' => $categoryName], [
					'slug' => Str::slug($categoryName) . '-' . Str::random(4),
				]);
			}

			$product = Product::query()->firstOrNew(['name' => $name]);
			$product->fill([
				'description' => $description,
				'price' => (float) $price,
				'stock_quantity' => (int) $stock,
				'is_active' => (int) $isActive === 1,
			]);

			if ($category) {
				$product->category_id = $category->id;
			}

			if (!$product->exists || !$product->slug) {
				$product->slug = Str::slug($name) . '-' . Str::random(4);
			}

			$product->save();

			$product->wasRecentlyCreated ? $created++ : $updated++;
		}

		fclose($handle);

		return back()->with('success', "Import completed. Created: {$created}, Updated: {$updated}.");
	}
}
