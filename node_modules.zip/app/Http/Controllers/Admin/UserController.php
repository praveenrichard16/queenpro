<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreUserRequest;
use App\Http\Requests\Admin\UpdateUserRequest;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class UserController extends Controller
{
    public function index(Request $request): View
    {
        $query = User::query()->latest();

        $search = $request->string('search')->toString();
        if ($search !== '') {
            $query->where(function ($innerQuery) use ($search) {
                $innerQuery->where('name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%")
                    ->orWhere('phone', 'like', "%{$search}%");
            });
        }

        $role = $request->input('role');
        if ($role) {
            if ($role === 'admin') {
                $query->where('is_admin', true);
            } elseif ($role === 'customer') {
                $query->where('is_admin', false);
            }
        }

        $users = $query->paginate(20)->withQueryString();

        return view('admin.users.index', [
            'users' => $users,
            'search' => $search,
            'selectedRole' => $role,
        ]);
    }

    public function create(): View
    {
        return view('admin.users.form', [
            'user' => new User(),
        ]);
    }

    public function store(StoreUserRequest $request): RedirectResponse
    {
        $data = $request->validated();
        $isSuperAdmin = (bool) $request->user()?->is_super_admin;

        $role = $isSuperAdmin ? $request->input('role', 'customer') : 'customer';
        $data['is_admin'] = $isSuperAdmin && $role === 'admin';
        $data['is_staff'] = $isSuperAdmin && $role === 'staff';

        if (!$isSuperAdmin) {
            $data['designation'] = null;
        }

        if ($request->hasFile('avatar')) {
            $data['avatar_path'] = $request->file('avatar')->store('users/avatars', 'public');
        }

        $data['password'] = Hash::make($data['password']);
        $data['is_super_admin'] = false;

        User::create($data);

        return redirect()
            ->route('admin.users.index')
            ->with('success', 'User created successfully.');
    }

    public function edit(User $user): View
    {
        return view('admin.users.form', compact('user'));
    }

    public function update(UpdateUserRequest $request, User $user): RedirectResponse
    {
        $data = $request->validated();
        $isSuperAdmin = (bool) $request->user()?->is_super_admin;

        if ($isSuperAdmin) {
            $role = $request->input('role', 'customer');
            $data['is_admin'] = $role === 'admin';
            $data['is_staff'] = $role === 'staff';
        } else {
            $data['is_admin'] = $user->is_admin;
            $data['is_staff'] = $user->is_staff;
            $data['designation'] = $user->designation;
        }

        if ($request->hasFile('avatar')) {
            if ($user->avatar_path) {
                Storage::disk('public')->delete($user->avatar_path);
            }
            $data['avatar_path'] = $request->file('avatar')->store('users/avatars', 'public');
        }

        if (!empty($data['password'])) {
            $data['password'] = Hash::make($data['password']);
        } else {
            unset($data['password'], $data['password_confirmation']);
        }

        $user->update($data);

        return redirect()
            ->route('admin.users.edit', $user)
            ->with('success', 'User updated successfully.');
    }

    public function destroy(User $user): RedirectResponse
    {
        if ($user->avatar_path) {
            Storage::disk('public')->delete($user->avatar_path);
        }

        $user->delete();

        return redirect()
            ->route('admin.users.index')
            ->with('success', 'User deleted successfully.');
    }
}

