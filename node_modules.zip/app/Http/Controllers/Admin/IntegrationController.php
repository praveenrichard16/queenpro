<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Services\Integration\Exceptions\IntegrationException;
use App\Services\Integration\FcmService;
use App\Services\Integration\MailTestService;
use App\Services\Integration\MetaWhatsAppService;
use App\Services\Integration\PaymentGatewayVerifier;
use App\Services\Integration\TwilioService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class IntegrationController extends Controller
{
    public function index(): View
    {
        $integrations = [
            'smtp' => $this->getJsonSetting('integration_email_smtp', [
                'enabled' => false,
                'host' => null,
                'port' => 587,
                'encryption' => 'tls',
                'username' => null,
                'password' => null,
                'from_name' => null,
                'from_email' => null,
            ]),
            'whatsapp_twilio' => $this->getJsonSetting('integration_whatsapp_twilio', [
                'enabled' => false,
                'account_sid' => null,
                'auth_token' => null,
                'from_number' => null,
                'sandbox_number' => null,
            ]),
            'whatsapp_meta' => $this->getJsonSetting('integration_whatsapp_meta', [
                'enabled' => false,
                'phone_number_id' => null,
                'whatsapp_business_account_id' => null,
                'business_account_id' => null,
                'app_id' => null,
                'app_secret' => null,
                'access_token' => null,
                'webhook_verify_token' => null,
            ]),
            'sms_twilio' => $this->getJsonSetting('integration_sms_twilio', [
                'enabled' => false,
                'account_sid' => null,
                'auth_token' => null,
                'from_number' => null,
                'messaging_service_sid' => null,
            ]),
            'push_fcm' => $this->getJsonSetting('integration_push_fcm', [
                'enabled' => false,
                'server_key' => null,
                'sender_id' => null,
                'project_id' => null,
            ]),
            'social_google' => $this->getJsonSetting('integration_social_google', [
                'enabled' => false,
                'client_id' => null,
                'client_secret' => null,
                'redirect_uri' => null,
            ]),
            'social_facebook' => $this->getJsonSetting('integration_social_facebook', [
                'enabled' => false,
                'app_id' => null,
                'app_secret' => null,
                'redirect_uri' => null,
            ]),
            'payments_tabby' => $this->getJsonSetting('integration_payments_tabby', [
                'enabled' => false,
                'region' => 'saudi-arabia',
                'public_key' => null,
                'secret_key' => null,
                'merchant_code' => null,
            ]),
            'payments_apple_pay' => $this->getJsonSetting('integration_payments_apple_pay', [
                'enabled' => false,
                'merchant_id' => null,
                'merchant_certificate' => null,
                'merchant_key' => null,
                'domain' => $this->defaultDomain(),
            ]),
            'payments_paypal' => $this->getJsonSetting('integration_payments_paypal', [
                'enabled' => false,
                'mode' => 'sandbox',
                'client_id' => null,
                'client_secret' => null,
                'webhook_id' => null,
            ]),
            'payments_stripe' => $this->getJsonSetting('integration_payments_stripe', [
                'enabled' => false,
                'publishable_key' => null,
                'secret_key' => null,
                'webhook_secret' => null,
            ]),
        ];

        return view('admin.integrations.index', [
            'integrations' => $integrations,
        ]);
    }

    public function updateSmtp(Request $request): RedirectResponse
    {
        $payload = $this->validatedSmtp($request);

        $this->saveJsonSetting('integration_email_smtp', $payload);
        $this->syncMailConfig($payload);

        return $this->redirectSuccess('email', 'SMTP settings updated successfully.');
    }

    public function testSmtp(Request $request, MailTestService $mailTestService): RedirectResponse
    {
        $payload = $this->validatedSmtp($request);

        $this->saveJsonSetting('integration_email_smtp', $payload);
        $this->syncMailConfig($payload);

        $recipient = $request->input('test_email') ?: (Auth::user()?->email ?? $payload['from_email']);

        try {
            $mailTestService->sendTestEmail($payload, $recipient);
        } catch (IntegrationException $exception) {
            return $this->redirectError('email', $exception->getMessage());
        }

        return $this->redirectSuccess('email', "Test email dispatched to {$recipient}.");
    }

    public function updateTwilioWhatsApp(Request $request): RedirectResponse
    {
        $payload = $this->validatedTwilioWhatsApp($request);

        $this->saveJsonSetting('integration_whatsapp_twilio', $payload);

        return $this->redirectSuccess('whatsapp', 'Twilio WhatsApp settings saved.');
    }

    public function testTwilioWhatsApp(Request $request, TwilioService $twilio): RedirectResponse
    {
        $payload = $this->validatedTwilioWhatsApp($request);

        $this->saveJsonSetting('integration_whatsapp_twilio', $payload);

        try {
            $twilio->verifyCredentials($payload);
        } catch (IntegrationException $exception) {
            return $this->redirectError('whatsapp', $exception->getMessage());
        }

        return $this->redirectSuccess('whatsapp', 'Twilio WhatsApp credentials verified successfully.');
    }

    public function updateMetaWhatsApp(Request $request): RedirectResponse
    {
        $payload = $this->validatedMetaWhatsApp($request);

        $this->saveJsonSetting('integration_whatsapp_meta', $payload);

        return $this->redirectSuccess('whatsapp', 'Meta WhatsApp Cloud API settings saved.');
    }

    public function testMetaWhatsApp(Request $request, MetaWhatsAppService $meta): RedirectResponse
    {
        $payload = $this->validatedMetaWhatsApp($request);

        $this->saveJsonSetting('integration_whatsapp_meta', $payload);

        try {
            $meta->verifyCredentials($payload);
        } catch (IntegrationException $exception) {
            return $this->redirectError('whatsapp', $exception->getMessage());
        }

        return $this->redirectSuccess('whatsapp', 'Meta WhatsApp API credentials verified successfully.');
    }

    public function updateTwilioSms(Request $request): RedirectResponse
    {
        $payload = $this->validatedTwilioSms($request);

        $this->saveJsonSetting('integration_sms_twilio', $payload);

        return $this->redirectSuccess('sms', 'Twilio SMS settings saved.');
    }

    public function testTwilioSms(Request $request, TwilioService $twilio): RedirectResponse
    {
        $payload = $this->validatedTwilioSms($request);

        $this->saveJsonSetting('integration_sms_twilio', $payload);

        try {
            $twilio->verifyCredentials($payload);
        } catch (IntegrationException $exception) {
            return $this->redirectError('sms', $exception->getMessage());
        }

        return $this->redirectSuccess('sms', 'Twilio SMS credentials verified successfully.');
    }

    public function updatePushFcm(Request $request): RedirectResponse
    {
        $payload = $this->validatedPushFcm($request);

        $this->saveJsonSetting('integration_push_fcm', $payload);

        return $this->redirectSuccess('push', 'Firebase Cloud Messaging settings saved.');
    }

    public function testPushFcm(Request $request, FcmService $fcm): RedirectResponse
    {
        $payload = $this->validatedPushFcm($request);

        $this->saveJsonSetting('integration_push_fcm', $payload);

        try {
            $fcm->sendTestNotification($payload, 'WowDash Admin', 'This is a test push notification.');
        } catch (IntegrationException $exception) {
            return $this->redirectError('push', $exception->getMessage());
        }

        return $this->redirectSuccess('push', 'Firebase server key verified successfully.');
    }

    public function updateSocialGoogle(Request $request): RedirectResponse
    {
        $payload = $this->validatedSocialGoogle($request);

        $this->saveJsonSetting('integration_social_google', $payload);
        $this->syncSocialConfig('google', $payload);

        return $this->redirectSuccess('social', 'Google Login settings saved.');
    }

    public function testSocialGoogle(Request $request): RedirectResponse
    {
        $payload = $this->validatedSocialGoogle($request);

        $this->saveJsonSetting('integration_social_google', $payload);
        $this->syncSocialConfig('google', $payload);

        if (empty($payload['client_id']) || !str_ends_with($payload['client_id'], '.apps.googleusercontent.com')) {
            return $this->redirectError('social', 'Google client ID should end with .apps.googleusercontent.com');
        }

        return $this->redirectSuccess('social', 'Google OAuth credentials stored. Complete the OAuth flow to finalise verification.');
    }

    public function updateSocialFacebook(Request $request): RedirectResponse
    {
        $payload = $this->validatedSocialFacebook($request);

        $this->saveJsonSetting('integration_social_facebook', $payload);
        $this->syncSocialConfig('facebook', $payload);

        return $this->redirectSuccess('social', 'Facebook Login settings saved.');
    }

    public function testSocialFacebook(Request $request): RedirectResponse
    {
        $payload = $this->validatedSocialFacebook($request);

        $this->saveJsonSetting('integration_social_facebook', $payload);
        $this->syncSocialConfig('facebook', $payload);

        try {
            $response = \Illuminate\Support\Facades\Http::asForm()->post('https://graph.facebook.com/oauth/access_token', [
                'client_id' => $payload['app_id'],
                'client_secret' => $payload['app_secret'],
                'grant_type' => 'client_credentials',
            ]);

            if ($response->failed()) {
                return $this->redirectError('social', 'Facebook returned an error: ' . $response->body());
            }
        } catch (\Throwable $exception) {
            return $this->redirectError('social', 'Unable to reach Facebook OAuth: ' . $exception->getMessage());
        }

        return $this->redirectSuccess('social', 'Facebook OAuth credentials verified successfully.');
    }

    public function updatePaymentsTabby(Request $request): RedirectResponse
    {
        $payload = $this->validatedPaymentsTabby($request);

        $this->saveJsonSetting('integration_payments_tabby', $payload);
        $this->syncPaymentConfig('tabby', $payload);

        return $this->redirectSuccess('payments', 'Tabby settings saved.');
    }

    public function testPaymentsTabby(Request $request, PaymentGatewayVerifier $verifier): RedirectResponse
    {
        $payload = $this->validatedPaymentsTabby($request);

        $this->saveJsonSetting('integration_payments_tabby', $payload);
        $this->syncPaymentConfig('tabby', $payload);

        try {
            $verifier->verifyTabby($payload);
        } catch (IntegrationException $exception) {
            return $this->redirectError('payments', $exception->getMessage());
        }

        return $this->redirectSuccess('payments', 'Tabby credentials verified successfully.');
    }

    public function updatePaymentsApple(Request $request): RedirectResponse
    {
        $payload = $this->validatedPaymentsApple($request);

        $this->saveJsonSetting('integration_payments_apple_pay', $payload);
        $this->syncPaymentConfig('apple_pay', $payload);

        return $this->redirectSuccess('payments', 'Apple Pay settings saved.');
    }

    public function testPaymentsApple(Request $request, PaymentGatewayVerifier $verifier): RedirectResponse
    {
        $payload = $this->validatedPaymentsApple($request);

        $this->saveJsonSetting('integration_payments_apple_pay', $payload);
        $this->syncPaymentConfig('apple_pay', $payload);

        try {
            $verifier->verifyApplePay($payload);
        } catch (IntegrationException $exception) {
            return $this->redirectError('payments', $exception->getMessage());
        }

        return $this->redirectSuccess('payments', 'Apple Pay certificate parsed successfully.');
    }

    public function updatePaymentsPayPal(Request $request): RedirectResponse
    {
        $payload = $this->validatedPaymentsPayPal($request);

        $this->saveJsonSetting('integration_payments_paypal', $payload);
        $this->syncPaymentConfig('paypal', $payload);

        return $this->redirectSuccess('payments', 'PayPal settings saved.');
    }

    public function testPaymentsPayPal(Request $request, PaymentGatewayVerifier $verifier): RedirectResponse
    {
        $payload = $this->validatedPaymentsPayPal($request);

        $this->saveJsonSetting('integration_payments_paypal', $payload);
        $this->syncPaymentConfig('paypal', $payload);

        try {
            $verifier->verifyPayPal($payload);
        } catch (IntegrationException $exception) {
            return $this->redirectError('payments', $exception->getMessage());
        }

        return $this->redirectSuccess('payments', 'PayPal credentials verified successfully.');
    }

    public function updatePaymentsStripe(Request $request): RedirectResponse
    {
        $payload = $this->validatedPaymentsStripe($request);

        $this->saveJsonSetting('integration_payments_stripe', $payload);
        $this->syncPaymentConfig('stripe', $payload);

        return $this->redirectSuccess('payments', 'Stripe settings saved.');
    }

    public function testPaymentsStripe(Request $request, PaymentGatewayVerifier $verifier): RedirectResponse
    {
        $payload = $this->validatedPaymentsStripe($request);

        $this->saveJsonSetting('integration_payments_stripe', $payload);
        $this->syncPaymentConfig('stripe', $payload);

        try {
            $verifier->verifyStripe($payload);
        } catch (IntegrationException $exception) {
            return $this->redirectError('payments', $exception->getMessage());
        }

        return $this->redirectSuccess('payments', 'Stripe credentials verified successfully.');
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedSmtp(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'host' => ['nullable', 'string', 'max:255'],
            'port' => ['nullable', 'integer', 'min:1', 'max:65535'],
            'encryption' => ['nullable', Rule::in(['tls', 'ssl', 'none'])],
            'username' => ['nullable', 'string', 'max:255'],
            'password' => ['nullable', 'string', 'max:255'],
            'from_name' => ['nullable', 'string', 'max:255'],
            'from_email' => ['nullable', 'email', 'max:255'],
            'active_tab' => ['nullable', 'string'],
            'test_email' => ['nullable', 'email', 'max:255'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'host' => $data['host'] ?? null,
            'port' => $data['port'] ?? 587,
            'encryption' => $data['encryption'] ?? 'tls',
            'username' => $data['username'] ?? null,
            'password' => $data['password'] ?? null,
            'from_name' => $data['from_name'] ?? null,
            'from_email' => $data['from_email'] ?? null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedTwilioWhatsApp(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'account_sid' => ['nullable', 'string', 'max:64'],
            'auth_token' => ['nullable', 'string', 'max:128'],
            'from_number' => ['nullable', 'string', 'max:32'],
            'sandbox_number' => ['nullable', 'string', 'max:32'],
            'active_tab' => ['nullable', 'string'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'account_sid' => $data['account_sid'] ?? null,
            'auth_token' => $data['auth_token'] ?? null,
            'from_number' => $data['from_number'] ?? null,
            'sandbox_number' => $data['sandbox_number'] ?? null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedMetaWhatsApp(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'phone_number_id' => ['nullable', 'string', 'max:64'],
            'whatsapp_business_account_id' => ['nullable', 'string', 'max:64'],
            'business_account_id' => ['nullable', 'string', 'max:64'],
            'app_id' => ['nullable', 'string', 'max:64'],
            'app_secret' => ['nullable', 'string', 'max:128'],
            'access_token' => ['nullable', 'string', 'max:512'],
            'webhook_verify_token' => ['nullable', 'string', 'max:128'],
            'active_tab' => ['nullable', 'string'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'phone_number_id' => $data['phone_number_id'] ?? null,
            'whatsapp_business_account_id' => $data['whatsapp_business_account_id'] ?? null,
            'business_account_id' => $data['business_account_id'] ?? null,
            'app_id' => $data['app_id'] ?? null,
            'app_secret' => $data['app_secret'] ?? null,
            'access_token' => $data['access_token'] ?? null,
            'webhook_verify_token' => $data['webhook_verify_token'] ?? null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedTwilioSms(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'account_sid' => ['nullable', 'string', 'max:64'],
            'auth_token' => ['nullable', 'string', 'max:128'],
            'from_number' => ['nullable', 'string', 'max:32'],
            'messaging_service_sid' => ['nullable', 'string', 'max:64'],
            'active_tab' => ['nullable', 'string'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'account_sid' => $data['account_sid'] ?? null,
            'auth_token' => $data['auth_token'] ?? null,
            'from_number' => $data['from_number'] ?? null,
            'messaging_service_sid' => $data['messaging_service_sid'] ?? null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedPushFcm(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'server_key' => ['nullable', 'string'],
            'sender_id' => ['nullable', 'string', 'max:128'],
            'project_id' => ['nullable', 'string', 'max:128'],
            'active_tab' => ['nullable', 'string'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'server_key' => $data['server_key'] ?? null,
            'sender_id' => $data['sender_id'] ?? null,
            'project_id' => $data['project_id'] ?? null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedSocialGoogle(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'client_id' => ['nullable', 'string', 'max:255'],
            'client_secret' => ['nullable', 'string', 'max:255'],
            'redirect_uri' => ['nullable', 'url', 'max:255'],
            'active_tab' => ['nullable', 'string'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'client_id' => $data['client_id'] ?? null,
            'client_secret' => $data['client_secret'] ?? null,
            'redirect_uri' => $data['redirect_uri'] ?? null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedSocialFacebook(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'app_id' => ['nullable', 'string', 'max:255'],
            'app_secret' => ['nullable', 'string', 'max:255'],
            'redirect_uri' => ['nullable', 'url', 'max:255'],
            'active_tab' => ['nullable', 'string'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'app_id' => $data['app_id'] ?? null,
            'app_secret' => $data['app_secret'] ?? null,
            'redirect_uri' => $data['redirect_uri'] ?? null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedPaymentsTabby(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'region' => ['nullable', Rule::in(['saudi-arabia', 'united-arab-emirates'])],
            'public_key' => ['nullable', 'string', 'max:255'],
            'secret_key' => ['nullable', 'string', 'max:255'],
            'merchant_code' => ['nullable', 'string', 'max:255'],
            'active_tab' => ['nullable', 'string'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'region' => $data['region'] ?? 'saudi-arabia',
            'public_key' => $data['public_key'] ?? null,
            'secret_key' => $data['secret_key'] ?? null,
            'merchant_code' => $data['merchant_code'] ?? null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedPaymentsApple(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'merchant_id' => ['nullable', 'string', 'max:255'],
            'merchant_certificate' => ['nullable', 'string'],
            'merchant_key' => ['nullable', 'string'],
            'domain' => ['nullable', 'string', 'max:255'],
            'active_tab' => ['nullable', 'string'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'merchant_id' => $data['merchant_id'] ?? null,
            'merchant_certificate' => $data['merchant_certificate'] ?? null,
            'merchant_key' => $data['merchant_key'] ?? null,
            'domain' => $data['domain'] ?? $this->defaultDomain(),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedPaymentsPayPal(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'mode' => ['nullable', Rule::in(['sandbox', 'live'])],
            'client_id' => ['nullable', 'string', 'max:255'],
            'client_secret' => ['nullable', 'string', 'max:255'],
            'webhook_id' => ['nullable', 'string', 'max:255'],
            'active_tab' => ['nullable', 'string'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'mode' => $data['mode'] ?? 'sandbox',
            'client_id' => $data['client_id'] ?? null,
            'client_secret' => $data['client_secret'] ?? null,
            'webhook_id' => $data['webhook_id'] ?? null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function validatedPaymentsStripe(Request $request): array
    {
        $data = $request->validate([
            'enabled' => ['nullable'],
            'publishable_key' => ['nullable', 'string', 'max:255'],
            'secret_key' => ['nullable', 'string', 'max:255'],
            'webhook_secret' => ['nullable', 'string', 'max:255'],
            'active_tab' => ['nullable', 'string'],
        ]);

        return [
            'enabled' => $request->boolean('enabled'),
            'publishable_key' => $data['publishable_key'] ?? null,
            'secret_key' => $data['secret_key'] ?? null,
            'webhook_secret' => $data['webhook_secret'] ?? null,
        ];
    }

    protected function saveJsonSetting(string $key, array $payload): void
    {
        Setting::setValue($key, json_encode($payload), 'json');
    }

    protected function redirectSuccess(string $tab, string $message): RedirectResponse
    {
        session()->flash('active_tab', $tab);

        return back()->with('success', $message);
    }

    protected function redirectError(string $tab, string $message): RedirectResponse
    {
        session()->flash('active_tab', $tab);

        return back()->withInput()->with('error', $message);
    }

    protected function syncMailConfig(array $payload): void
    {
        config([
            'mail.mailers.smtp.host' => $payload['host'] ?: config('mail.mailers.smtp.host'),
            'mail.mailers.smtp.port' => $payload['port'] ?? config('mail.mailers.smtp.port'),
            'mail.mailers.smtp.encryption' => $payload['encryption'] === 'none' ? null : $payload['encryption'],
            'mail.mailers.smtp.username' => $payload['username'],
            'mail.mailers.smtp.password' => $payload['password'],
            'mail.from.address' => $payload['from_email'] ?: config('mail.from.address'),
            'mail.from.name' => $payload['from_name'] ?: config('mail.from.name'),
        ]);
    }

    protected function syncSocialConfig(string $provider, array $payload): void
    {
        $key = "services.{$provider}";

        $config = config($key, []);
        $config['client_id'] = $payload['client_id'] ?? $payload['app_id'] ?? null;
        $config['client_secret'] = $payload['client_secret'] ?? $payload['app_secret'] ?? null;
        $config['redirect'] = $payload['redirect_uri'] ?? null;

        config([$key => $config]);
    }

    protected function syncPaymentConfig(string $gateway, array $payload): void
    {
        $key = "payment.{$gateway}";
        $config = config($key, []);

        $map = match ($gateway) {
            'tabby' => [
                'enabled' => $payload['enabled'],
                'region' => $payload['region'],
                'public_key' => $payload['public_key'],
                'secret_key' => $payload['secret_key'],
                'merchant_code' => $payload['merchant_code'],
            ],
            'apple_pay' => [
                'enabled' => $payload['enabled'],
                'merchant_id' => $payload['merchant_id'],
                'merchant_certificate' => $payload['merchant_certificate'],
                'merchant_key' => $payload['merchant_key'],
                'domain' => $payload['domain'],
            ],
            'paypal' => [
                'enabled' => $payload['enabled'],
                'mode' => $payload['mode'],
                'client_id' => $payload['client_id'],
                'client_secret' => $payload['client_secret'],
                'webhook_id' => $payload['webhook_id'],
            ],
            'stripe' => [
                'enabled' => $payload['enabled'],
                'publishable_key' => $payload['publishable_key'],
                'secret_key' => $payload['secret_key'],
                'webhook_secret' => $payload['webhook_secret'],
            ],
            default => [],
        };

        config([$key => array_merge($config, $map)]);
    }

    protected function getJsonSetting(string $key, array $defaults = []): array
    {
        $value = Setting::getValue($key);

        if (!is_array($value)) {
            return $defaults;
        }

        return array_merge($defaults, $value);
    }

    protected function defaultDomain(): string
    {
        $request = request();

        if ($request) {
            return $request->getHost();
        }

        $url = config('app.url', 'http://localhost');

        return parse_url($url, PHP_URL_HOST) ?: 'localhost';
    }
}

