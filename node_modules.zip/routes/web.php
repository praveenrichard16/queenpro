<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\Admin\BlogCategoryController as AdminBlogCategoryController;
use App\Http\Controllers\Admin\BlogPostController as AdminBlogPostController;
use App\Http\Controllers\Admin\BlogTagController as AdminBlogTagController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ProductController as AdminProductController;
use App\Http\Controllers\Admin\SettingController as AdminSettingController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\Admin\SeoToolController as AdminSeoToolController;
use App\Http\Controllers\Admin\IntegrationController as AdminIntegrationController;
use App\Http\Controllers\Admin\SupportTicketController as AdminSupportTicketController;
use App\Http\Controllers\Admin\SupportSettingController as AdminSupportSettingController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Home page
Route::get('/', [HomeController::class, 'index'])->name('home');

// Static Pages
Route::view('/about-us', 'pages.about')->name('about');
Route::view('/contact-us', 'pages.contact')->name('contact');
Route::view('/privacy-policy', 'pages.privacy')->name('privacy');
Route::view('/terms-and-conditions', 'pages.terms')->name('terms');
Route::view('/refund-and-return-policy', 'pages.refund')->name('refund');
Route::view('/wishlist', 'pages.wishlist')->name('wishlist.index');
Route::view('/compare', 'pages.compare')->name('compare.index');

// Blog routes
Route::prefix('blog')->group(function () {
	Route::get('/', [BlogController::class, 'index'])->name('blog.index');
	Route::get('/category/{slug}', [BlogController::class, 'category'])->name('blog.category');
	Route::get('/{slug}', [BlogController::class, 'show'])->name('blog.show');
});

// Product routes
Route::get('/products', [ProductController::class, 'index'])->name('products.index');
Route::get('/products/{id}', [ProductController::class, 'show'])->name('products.show');
Route::get('/category/{category}', [ProductController::class, 'category'])->name('products.category');

// Cart routes
Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');
Route::post('/cart/update', [CartController::class, 'update'])->name('cart.update');
Route::post('/cart/remove', [CartController::class, 'remove'])->name('cart.remove');
Route::post('/cart/clear', [CartController::class, 'clear'])->name('cart.clear');

// Order routes
Route::get('/checkout', [OrderController::class, 'checkout'])->name('checkout');
Route::post('/orders', [OrderController::class, 'store'])->name('orders.store');
Route::get('/orders/{id}', [OrderController::class, 'show'])->name('orders.show');
Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');

// Minimal Auth routes
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.perform');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Dashboards & Admin
Route::middleware('auth')->group(function () {
	Route::get('/dashboard', function () {
		return auth()->user()->is_admin
			? redirect()->route('admin.dashboard')
			: redirect()->route('customer.dashboard');
	})->name('dashboard');

	Route::get('/customer/dashboard', function () {
		return view('dashboards.customer');
	})->name('customer.dashboard');

	Route::prefix('admin')->middleware('admin')->group(function () {
		Route::get('/', [DashboardController::class, 'index'])->name('admin.dashboard');
		Route::get('products/export', [AdminProductController::class, 'export'])->name('admin.products.export');
		Route::post('products/import', [AdminProductController::class, 'import'])->name('admin.products.import');
		Route::delete('products/{product}/images/{image}', [AdminProductController::class, 'destroyImage'])->name('admin.products.images.destroy');
		Route::resource('products', AdminProductController::class)->names('admin.products')->except(['show']);
        Route::resource('orders', \App\Http\Controllers\Admin\OrderController::class)
         ->names('admin.orders')
         ->only(['index', 'show', 'update']);
		Route::get('profile', [\App\Http\Controllers\Admin\ProfileController::class, 'show'])->name('admin.profile');
		Route::post('profile', [\App\Http\Controllers\Admin\ProfileController::class, 'update'])->name('admin.profile.update');
		Route::post('profile/password', [\App\Http\Controllers\Admin\ProfileController::class, 'password'])->name('admin.profile.password');
        Route::resource('categories', \App\Http\Controllers\Admin\CategoryController::class)->names('admin.categories')->except(['show']);
        Route::resource('tags', \App\Http\Controllers\Admin\TagController::class)->names('admin.tags')->except(['show']);
        Route::resource('users', AdminUserController::class)->names('admin.users')->except(['show']);
        Route::prefix('blog')->name('admin.blog.')->group(function () {
            Route::resource('posts', AdminBlogPostController::class)->except(['show']);
            Route::resource('categories', AdminBlogCategoryController::class)->except(['show']);
            Route::resource('tags', AdminBlogTagController::class)->except(['show']);
        });
		Route::get('settings/general', [AdminSettingController::class, 'edit'])->name('admin.settings.general');
		Route::post('settings/general', [AdminSettingController::class, 'update'])->name('admin.settings.update');
		Route::get('settings/seo', [AdminSeoToolController::class, 'edit'])->name('admin.settings.seo');
		Route::post('settings/seo/robots', [AdminSeoToolController::class, 'updateRobots'])->name('admin.settings.seo.robots.update');
		Route::post('settings/seo/robots/reset', [AdminSeoToolController::class, 'resetRobots'])->name('admin.settings.seo.robots.reset');
		Route::get('settings/seo/robots/download', [AdminSeoToolController::class, 'downloadRobots'])->name('admin.settings.seo.robots.download');
		Route::post('settings/seo/sitemap', [AdminSeoToolController::class, 'generateSitemap'])->name('admin.settings.seo.sitemap.generate');
		Route::get('settings/seo/sitemap/download', [AdminSeoToolController::class, 'downloadSitemap'])->name('admin.settings.seo.sitemap.download');

		Route::get('integrations', [AdminIntegrationController::class, 'index'])->name('admin.integrations.index');
		Route::post('integrations/email/smtp', [AdminIntegrationController::class, 'updateSmtp'])->name('admin.integrations.smtp.update');
		Route::post('integrations/email/smtp/test', [AdminIntegrationController::class, 'testSmtp'])->name('admin.integrations.smtp.test');
		Route::post('integrations/whatsapp/twilio', [AdminIntegrationController::class, 'updateTwilioWhatsApp'])->name('admin.integrations.whatsapp.twilio.update');
		Route::post('integrations/whatsapp/twilio/test', [AdminIntegrationController::class, 'testTwilioWhatsApp'])->name('admin.integrations.whatsapp.twilio.test');
		Route::post('integrations/whatsapp/meta', [AdminIntegrationController::class, 'updateMetaWhatsApp'])->name('admin.integrations.whatsapp.meta.update');
		Route::post('integrations/whatsapp/meta/test', [AdminIntegrationController::class, 'testMetaWhatsApp'])->name('admin.integrations.whatsapp.meta.test');
		Route::post('integrations/sms/twilio', [AdminIntegrationController::class, 'updateTwilioSms'])->name('admin.integrations.sms.twilio.update');
		Route::post('integrations/sms/twilio/test', [AdminIntegrationController::class, 'testTwilioSms'])->name('admin.integrations.sms.twilio.test');
		Route::post('integrations/push/fcm', [AdminIntegrationController::class, 'updatePushFcm'])->name('admin.integrations.push.fcm.update');
        Route::post('integrations/push/fcm/test', [AdminIntegrationController::class, 'testPushFcm'])->name('admin.integrations.push.fcm.test');
		Route::post('integrations/social/google', [AdminIntegrationController::class, 'updateSocialGoogle'])->name('admin.integrations.social.google.update');
		Route::post('integrations/social/google/test', [AdminIntegrationController::class, 'testSocialGoogle'])->name('admin.integrations.social.google.test');
		Route::post('integrations/social/facebook', [AdminIntegrationController::class, 'updateSocialFacebook'])->name('admin.integrations.social.facebook.update');
		Route::post('integrations/social/facebook/test', [AdminIntegrationController::class, 'testSocialFacebook'])->name('admin.integrations.social.facebook.test');
		Route::post('integrations/payments/tabby', [AdminIntegrationController::class, 'updatePaymentsTabby'])->name('admin.integrations.payments.tabby.update');
		Route::post('integrations/payments/tabby/test', [AdminIntegrationController::class, 'testPaymentsTabby'])->name('admin.integrations.payments.tabby.test');
		Route::post('integrations/payments/apple', [AdminIntegrationController::class, 'updatePaymentsApple'])->name('admin.integrations.payments.apple.update');
		Route::post('integrations/payments/apple/test', [AdminIntegrationController::class, 'testPaymentsApple'])->name('admin.integrations.payments.apple.test');
		Route::post('integrations/payments/paypal', [AdminIntegrationController::class, 'updatePaymentsPayPal'])->name('admin.integrations.payments.paypal.update');
		Route::post('integrations/payments/paypal/test', [AdminIntegrationController::class, 'testPaymentsPayPal'])->name('admin.integrations.payments.paypal.test');
		Route::post('integrations/payments/stripe', [AdminIntegrationController::class, 'updatePaymentsStripe'])->name('admin.integrations.payments.stripe.update');
		Route::post('integrations/payments/stripe/test', [AdminIntegrationController::class, 'testPaymentsStripe'])->name('admin.integrations.payments.stripe.test');

		Route::prefix('support')->name('admin.support.')->group(function () {
			Route::get('tickets', [AdminSupportTicketController::class, 'index'])->name('tickets.index');
			Route::get('tickets/{ticket}', [AdminSupportTicketController::class, 'show'])->name('tickets.show');
			Route::get('settings', [AdminSupportSettingController::class, 'edit'])->name('settings.edit');
			Route::post('settings', [AdminSupportSettingController::class, 'update'])->name('settings.update');
		});
	});
});

// Auth (Breeze) if present
if (file_exists(base_path('routes/auth.php'))) {
	require base_path('routes/auth.php');
}
